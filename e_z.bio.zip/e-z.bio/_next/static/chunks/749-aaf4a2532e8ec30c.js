(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [749], {
        2350: function() {},
        3454: function(e, t, n) {
            "use strict";
            var i, r;
            e.exports = (null == (i = n.g.process) ? void 0 : i.env) && "object" == typeof(null == (r = n.g.process) ? void 0 : r.env) ? n.g.process : n(7663)
        },
        5677: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var n in t) Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: t[n]
                    })
                }(t, {
                    noSSR: function() {
                        return s
                    },
                    default: function() {
                        return a
                    }
                });
            let i = n(8754),
                r = (n(7294), i._(n(8976)));

            function o(e) {
                return {
                    default: (null == e ? void 0 : e.default) || e
                }
            }

            function s(e, t) {
                return delete t.webpack, delete t.modules, e(t)
            }

            function a(e, t) {
                let n = r.default,
                    i = {
                        loading: e => {
                            let {
                                error: t,
                                isLoading: n,
                                pastDelay: i
                            } = e;
                            return null
                        }
                    };
                e instanceof Promise ? i.loader = () => e : "function" == typeof e ? i.loader = e : "object" == typeof e && (i = { ...i,
                    ...e
                }), i = { ...i,
                    ...t
                };
                let a = i.loader,
                    l = () => null != a ? a().then(o) : Promise.resolve(o(() => null));
                return (i.loadableGenerated && (i = { ...i,
                    ...i.loadableGenerated
                }, delete i.loadableGenerated), "boolean" != typeof i.ssr || i.ssr) ? n({ ...i,
                    loader: l
                }) : (delete i.webpack, delete i.modules, s(n, i))
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        2254: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "LoadableContext", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            let i = n(8754),
                r = i._(n(7294)),
                o = r.default.createContext(null)
        },
        8976: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return p
                }
            });
            let i = n(8754),
                r = i._(n(7294)),
                o = n(2254),
                s = [],
                a = [],
                l = !1;

            function u(e) {
                let t = e(),
                    n = {
                        loading: !0,
                        loaded: null,
                        error: null
                    };
                return n.promise = t.then(e => (n.loading = !1, n.loaded = e, e)).catch(e => {
                    throw n.loading = !1, n.error = e, e
                }), n
            }
            class c {
                promise() {
                    return this._res.promise
                }
                retry() {
                    this._clearTimeouts(), this._res = this._loadFn(this._opts.loader), this._state = {
                        pastDelay: !1,
                        timedOut: !1
                    };
                    let {
                        _res: e,
                        _opts: t
                    } = this;
                    e.loading && ("number" == typeof t.delay && (0 === t.delay ? this._state.pastDelay = !0 : this._delay = setTimeout(() => {
                        this._update({
                            pastDelay: !0
                        })
                    }, t.delay)), "number" == typeof t.timeout && (this._timeout = setTimeout(() => {
                        this._update({
                            timedOut: !0
                        })
                    }, t.timeout))), this._res.promise.then(() => {
                        this._update({}), this._clearTimeouts()
                    }).catch(e => {
                        this._update({}), this._clearTimeouts()
                    }), this._update({})
                }
                _update(e) {
                    this._state = { ...this._state,
                        error: this._res.error,
                        loaded: this._res.loaded,
                        loading: this._res.loading,
                        ...e
                    }, this._callbacks.forEach(e => e())
                }
                _clearTimeouts() {
                    clearTimeout(this._delay), clearTimeout(this._timeout)
                }
                getCurrentValue() {
                    return this._state
                }
                subscribe(e) {
                    return this._callbacks.add(e), () => {
                        this._callbacks.delete(e)
                    }
                }
                constructor(e, t) {
                    this._loadFn = e, this._opts = t, this._callbacks = new Set, this._delay = null, this._timeout = null, this.retry()
                }
            }

            function d(e) {
                return function(e, t) {
                    let n = Object.assign({
                            loader: null,
                            loading: null,
                            delay: 200,
                            timeout: null,
                            webpack: null,
                            modules: null
                        }, t),
                        i = null;

                    function s() {
                        if (!i) {
                            let t = new c(e, n);
                            i = {
                                getCurrentValue: t.getCurrentValue.bind(t),
                                subscribe: t.subscribe.bind(t),
                                retry: t.retry.bind(t),
                                promise: t.promise.bind(t)
                            }
                        }
                        return i.promise()
                    }
                    if (!l) {
                        let e = n.webpack ? n.webpack() : n.modules;
                        e && a.push(t => {
                            for (let n of e)
                                if (-1 !== t.indexOf(n)) return s()
                        })
                    }

                    function u(e, t) {
                        ! function() {
                            s();
                            let e = r.default.useContext(o.LoadableContext);
                            e && Array.isArray(n.modules) && n.modules.forEach(t => {
                                e(t)
                            })
                        }();
                        let a = r.default.useSyncExternalStore(i.subscribe, i.getCurrentValue, i.getCurrentValue);
                        return r.default.useImperativeHandle(t, () => ({
                            retry: i.retry
                        }), []), r.default.useMemo(() => {
                            var t;
                            return a.loading || a.error ? r.default.createElement(n.loading, {
                                isLoading: a.loading,
                                pastDelay: a.pastDelay,
                                timedOut: a.timedOut,
                                error: a.error,
                                retry: i.retry
                            }) : a.loaded ? r.default.createElement((t = a.loaded) && t.default ? t.default : t, e) : null
                        }, [e, a])
                    }
                    return u.preload = () => s(), u.displayName = "LoadableComponent", r.default.forwardRef(u)
                }(u, e)
            }

            function h(e, t) {
                let n = [];
                for (; e.length;) {
                    let i = e.pop();
                    n.push(i(t))
                }
                return Promise.all(n).then(() => {
                    if (e.length) return h(e, t)
                })
            }
            d.preloadAll = () => new Promise((e, t) => {
                h(s).then(e, t)
            }), d.preloadReady = e => (void 0 === e && (e = []), new Promise(t => {
                let n = () => (l = !0, t());
                h(a, e).then(n, n)
            })), window.__NEXT_PRELOADREADY = d.preloadReady;
            let p = d
        },
        9578: function(e, t, n) {
            var i = n(3454);
            n(2350);
            var r = n(7294),
                o = r && "object" == typeof r && "default" in r ? r : {
                    default: r
                };

            function s(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var i = t[n];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                }
            }
            var a = void 0 !== i && i.env && !0,
                l = function(e) {
                    return "[object String]" === Object.prototype.toString.call(e)
                },
                u = function() {
                    function e(e) {
                        var t = void 0 === e ? {} : e,
                            n = t.name,
                            i = void 0 === n ? "stylesheet" : n,
                            r = t.optimizeForSpeed,
                            o = void 0 === r ? a : r;
                        c(l(i), "`name` must be a string"), this._name = i, this._deletedRulePlaceholder = "#" + i + "-deleted-rule____{}", c("boolean" == typeof o, "`optimizeForSpeed` must be a boolean"), this._optimizeForSpeed = o, this._serverSheet = void 0, this._tags = [], this._injected = !1, this._rulesCount = 0;
                        var s = document.querySelector('meta[property="csp-nonce"]');
                        this._nonce = s ? s.getAttribute("content") : null
                    }
                    var t, n = e.prototype;
                    return n.setOptimizeForSpeed = function(e) {
                        c("boolean" == typeof e, "`setOptimizeForSpeed` accepts a boolean"), c(0 === this._rulesCount, "optimizeForSpeed cannot be when rules have already been inserted"), this.flush(), this._optimizeForSpeed = e, this.inject()
                    }, n.isOptimizeForSpeed = function() {
                        return this._optimizeForSpeed
                    }, n.inject = function() {
                        var e = this;
                        if (c(!this._injected, "sheet already injected"), this._injected = !0, this._optimizeForSpeed) {
                            this._tags[0] = this.makeStyleTag(this._name), this._optimizeForSpeed = "insertRule" in this.getSheet(), this._optimizeForSpeed || (a || console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."), this.flush(), this._injected = !0);
                            return
                        }
                        this._serverSheet = {
                            cssRules: [],
                            insertRule: function(t, n) {
                                return "number" == typeof n ? e._serverSheet.cssRules[n] = {
                                    cssText: t
                                } : e._serverSheet.cssRules.push({
                                    cssText: t
                                }), n
                            },
                            deleteRule: function(t) {
                                e._serverSheet.cssRules[t] = null
                            }
                        }
                    }, n.getSheetForTag = function(e) {
                        if (e.sheet) return e.sheet;
                        for (var t = 0; t < document.styleSheets.length; t++)
                            if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t]
                    }, n.getSheet = function() {
                        return this.getSheetForTag(this._tags[this._tags.length - 1])
                    }, n.insertRule = function(e, t) {
                        if (c(l(e), "`insertRule` accepts only strings"), this._optimizeForSpeed) {
                            var n = this.getSheet();
                            "number" != typeof t && (t = n.cssRules.length);
                            try {
                                n.insertRule(e, t)
                            } catch (t) {
                                return a || console.warn("StyleSheet: illegal rule: \n\n" + e + "\n\nSee https://stackoverflow.com/q/20007992 for more info"), -1
                            }
                        } else {
                            var i = this._tags[t];
                            this._tags.push(this.makeStyleTag(this._name, e, i))
                        }
                        return this._rulesCount++
                    }, n.replaceRule = function(e, t) {
                        if (this._optimizeForSpeed) {
                            var n = this.getSheet();
                            if (t.trim() || (t = this._deletedRulePlaceholder), !n.cssRules[e]) return e;
                            n.deleteRule(e);
                            try {
                                n.insertRule(t, e)
                            } catch (i) {
                                a || console.warn("StyleSheet: illegal rule: \n\n" + t + "\n\nSee https://stackoverflow.com/q/20007992 for more info"), n.insertRule(this._deletedRulePlaceholder, e)
                            }
                        } else {
                            var i = this._tags[e];
                            c(i, "old rule at index `" + e + "` not found"), i.textContent = t
                        }
                        return e
                    }, n.deleteRule = function(e) {
                        if (this._optimizeForSpeed) this.replaceRule(e, "");
                        else {
                            var t = this._tags[e];
                            c(t, "rule at index `" + e + "` not found"), t.parentNode.removeChild(t), this._tags[e] = null
                        }
                    }, n.flush = function() {
                        this._injected = !1, this._rulesCount = 0, this._tags.forEach(function(e) {
                            return e && e.parentNode.removeChild(e)
                        }), this._tags = []
                    }, n.cssRules = function() {
                        var e = this;
                        return this._tags.reduce(function(t, n) {
                            return n ? t = t.concat(Array.prototype.map.call(e.getSheetForTag(n).cssRules, function(t) {
                                return t.cssText === e._deletedRulePlaceholder ? null : t
                            })) : t.push(null), t
                        }, [])
                    }, n.makeStyleTag = function(e, t, n) {
                        t && c(l(t), "makeStyleTag accepts only strings as second parameter");
                        var i = document.createElement("style");
                        this._nonce && i.setAttribute("nonce", this._nonce), i.type = "text/css", i.setAttribute("data-" + e, ""), t && i.appendChild(document.createTextNode(t));
                        var r = document.head || document.getElementsByTagName("head")[0];
                        return n ? r.insertBefore(i, n) : r.appendChild(i), i
                    }, s(e.prototype, [{
                        key: "length",
                        get: function() {
                            return this._rulesCount
                        }
                    }]), t && s(e, t), e
                }();

            function c(e, t) {
                if (!e) throw Error("StyleSheet: " + t + ".")
            }
            var d = function(e) {
                    for (var t = 5381, n = e.length; n;) t = 33 * t ^ e.charCodeAt(--n);
                    return t >>> 0
                },
                h = {};

            function p(e, t) {
                if (!t) return "jsx-" + e;
                var n = String(t),
                    i = e + n;
                return h[i] || (h[i] = "jsx-" + d(e + "-" + n)), h[i]
            }

            function f(e, t) {
                var n = e + t;
                return h[n] || (h[n] = t.replace(/__jsx-style-dynamic-selector/g, e)), h[n]
            }
            var m = function() {
                    function e(e) {
                        var t = void 0 === e ? {} : e,
                            n = t.styleSheet,
                            i = void 0 === n ? null : n,
                            r = t.optimizeForSpeed,
                            o = void 0 !== r && r;
                        this._sheet = i || new u({
                            name: "styled-jsx",
                            optimizeForSpeed: o
                        }), this._sheet.inject(), i && "boolean" == typeof o && (this._sheet.setOptimizeForSpeed(o), this._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), this._fromServer = void 0, this._indices = {}, this._instancesCounts = {}
                    }
                    var t = e.prototype;
                    return t.add = function(e) {
                        var t = this;
                        void 0 === this._optimizeForSpeed && (this._optimizeForSpeed = Array.isArray(e.children), this._sheet.setOptimizeForSpeed(this._optimizeForSpeed), this._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), this._fromServer || (this._fromServer = this.selectFromServer(), this._instancesCounts = Object.keys(this._fromServer).reduce(function(e, t) {
                            return e[t] = 0, e
                        }, {}));
                        var n = this.getIdAndRules(e),
                            i = n.styleId,
                            r = n.rules;
                        if (i in this._instancesCounts) {
                            this._instancesCounts[i] += 1;
                            return
                        }
                        var o = r.map(function(e) {
                            return t._sheet.insertRule(e)
                        }).filter(function(e) {
                            return -1 !== e
                        });
                        this._indices[i] = o, this._instancesCounts[i] = 1
                    }, t.remove = function(e) {
                        var t = this,
                            n = this.getIdAndRules(e).styleId;
                        if (function(e, t) {
                                if (!e) throw Error("StyleSheetRegistry: " + t + ".")
                            }(n in this._instancesCounts, "styleId: `" + n + "` not found"), this._instancesCounts[n] -= 1, this._instancesCounts[n] < 1) {
                            var i = this._fromServer && this._fromServer[n];
                            i ? (i.parentNode.removeChild(i), delete this._fromServer[n]) : (this._indices[n].forEach(function(e) {
                                return t._sheet.deleteRule(e)
                            }), delete this._indices[n]), delete this._instancesCounts[n]
                        }
                    }, t.update = function(e, t) {
                        this.add(t), this.remove(e)
                    }, t.flush = function() {
                        this._sheet.flush(), this._sheet.inject(), this._fromServer = void 0, this._indices = {}, this._instancesCounts = {}
                    }, t.cssRules = function() {
                        var e = this,
                            t = this._fromServer ? Object.keys(this._fromServer).map(function(t) {
                                return [t, e._fromServer[t]]
                            }) : [],
                            n = this._sheet.cssRules();
                        return t.concat(Object.keys(this._indices).map(function(t) {
                            return [t, e._indices[t].map(function(e) {
                                return n[e].cssText
                            }).join(e._optimizeForSpeed ? "" : "\n")]
                        }).filter(function(e) {
                            return !!e[1]
                        }))
                    }, t.styles = function(e) {
                        var t, n;
                        return t = this.cssRules(), void 0 === (n = e) && (n = {}), t.map(function(e) {
                            var t = e[0],
                                i = e[1];
                            return o.default.createElement("style", {
                                id: "__" + t,
                                key: "__" + t,
                                nonce: n.nonce ? n.nonce : void 0,
                                dangerouslySetInnerHTML: {
                                    __html: i
                                }
                            })
                        })
                    }, t.getIdAndRules = function(e) {
                        var t = e.children,
                            n = e.dynamic,
                            i = e.id;
                        if (n) {
                            var r = p(i, n);
                            return {
                                styleId: r,
                                rules: Array.isArray(t) ? t.map(function(e) {
                                    return f(r, e)
                                }) : [f(r, t)]
                            }
                        }
                        return {
                            styleId: p(i),
                            rules: Array.isArray(t) ? t : [t]
                        }
                    }, t.selectFromServer = function() {
                        return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e, t) {
                            return e[t.id.slice(2)] = t, e
                        }, {})
                    }, e
                }(),
                g = r.createContext(null);
            g.displayName = "StyleSheetContext";
            var v = o.default.useInsertionEffect || o.default.useLayoutEffect,
                A = new m;

            function y(e) {
                var t = A || r.useContext(g);
                return t && v(function() {
                    return t.add(e),
                        function() {
                            t.remove(e)
                        }
                }, [e.id, String(e.dynamic)]), null
            }
            y.dynamic = function(e) {
                return e.map(function(e) {
                    return p(e[0], e[1])
                }).join(" ")
            }, t.style = y
        },
        6465: function(e, t, n) {
            "use strict";
            e.exports = n(9578).style
        },
        7663: function(e) {
            ! function() {
                var t = {
                        229: function(e) {
                            var t, n, i, r = e.exports = {};

                            function o() {
                                throw Error("setTimeout has not been defined")
                            }

                            function s() {
                                throw Error("clearTimeout has not been defined")
                            }

                            function a(e) {
                                if (t === setTimeout) return setTimeout(e, 0);
                                if ((t === o || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                                try {
                                    return t(e, 0)
                                } catch (n) {
                                    try {
                                        return t.call(null, e, 0)
                                    } catch (n) {
                                        return t.call(this, e, 0)
                                    }
                                }
                            }! function() {
                                try {
                                    t = "function" == typeof setTimeout ? setTimeout : o
                                } catch (e) {
                                    t = o
                                }
                                try {
                                    n = "function" == typeof clearTimeout ? clearTimeout : s
                                } catch (e) {
                                    n = s
                                }
                            }();
                            var l = [],
                                u = !1,
                                c = -1;

                            function d() {
                                u && i && (u = !1, i.length ? l = i.concat(l) : c = -1, l.length && h())
                            }

                            function h() {
                                if (!u) {
                                    var e = a(d);
                                    u = !0;
                                    for (var t = l.length; t;) {
                                        for (i = l, l = []; ++c < t;) i && i[c].run();
                                        c = -1, t = l.length
                                    }
                                    i = null, u = !1,
                                        function(e) {
                                            if (n === clearTimeout) return clearTimeout(e);
                                            if ((n === s || !n) && clearTimeout) return n = clearTimeout, clearTimeout(e);
                                            try {
                                                n(e)
                                            } catch (t) {
                                                try {
                                                    return n.call(null, e)
                                                } catch (t) {
                                                    return n.call(this, e)
                                                }
                                            }
                                        }(e)
                                }
                            }

                            function p(e, t) {
                                this.fun = e, this.array = t
                            }

                            function f() {}
                            r.nextTick = function(e) {
                                var t = Array(arguments.length - 1);
                                if (arguments.length > 1)
                                    for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                                l.push(new p(e, t)), 1 !== l.length || u || a(h)
                            }, p.prototype.run = function() {
                                this.fun.apply(null, this.array)
                            }, r.title = "browser", r.browser = !0, r.env = {}, r.argv = [], r.version = "", r.versions = {}, r.on = f, r.addListener = f, r.once = f, r.off = f, r.removeListener = f, r.removeAllListeners = f, r.emit = f, r.prependListener = f, r.prependOnceListener = f, r.listeners = function(e) {
                                return []
                            }, r.binding = function(e) {
                                throw Error("process.binding is not supported")
                            }, r.cwd = function() {
                                return "/"
                            }, r.chdir = function(e) {
                                throw Error("process.chdir is not supported")
                            }, r.umask = function() {
                                return 0
                            }
                        }
                    },
                    n = {};

                function i(e) {
                    var r = n[e];
                    if (void 0 !== r) return r.exports;
                    var o = n[e] = {
                            exports: {}
                        },
                        s = !0;
                    try {
                        t[e](o, o.exports, i), s = !1
                    } finally {
                        s && delete n[e]
                    }
                    return o.exports
                }
                i.ab = "//";
                var r = i(229);
                e.exports = r
            }()
        },
        5152: function(e, t, n) {
            e.exports = n(5677)
        },
        1163: function(e, t, n) {
            e.exports = n(6885)
        },
        1351: function(e, t, n) {
            "use strict";
            let i;
            n.d(t, {
                Z: function() {
                    return ex
                }
            });
            var r, o = n(7294);
            let s = Object.freeze({
                    left: 0,
                    top: 0,
                    width: 16,
                    height: 16
                }),
                a = Object.freeze({
                    rotate: 0,
                    vFlip: !1,
                    hFlip: !1
                }),
                l = Object.freeze({ ...s,
                    ...a
                }),
                u = Object.freeze({ ...l,
                    body: "",
                    hidden: !1
                });

            function c(e, t) {
                let n = function(e, t) {
                    let n = {};
                    !e.hFlip != !t.hFlip && (n.hFlip = !0), !e.vFlip != !t.vFlip && (n.vFlip = !0);
                    let i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
                    return i && (n.rotate = i), n
                }(e, t);
                for (let i in u) i in a ? i in e && !(i in n) && (n[i] = a[i]) : i in t ? n[i] = t[i] : i in e && (n[i] = e[i]);
                return n
            }

            function d(e, t) {
                let n = [];
                if ("object" != typeof e || "object" != typeof e.icons) return n;
                e.not_found instanceof Array && e.not_found.forEach(e => {
                    t(e, null), n.push(e)
                });
                let i = function(e, t) {
                    let n = e.icons,
                        i = e.aliases || Object.create(null),
                        r = Object.create(null);
                    return Object.keys(n).concat(Object.keys(i)).forEach(function e(t) {
                        if (n[t]) return r[t] = [];
                        if (!(t in r)) {
                            r[t] = null;
                            let n = i[t] && i[t].parent,
                                o = n && e(n);
                            o && (r[t] = [n].concat(o))
                        }
                        return r[t]
                    }), r
                }(e);
                for (let r in i) {
                    let o = i[r];
                    o && (t(r, function(e, t, n) {
                        let i = e.icons,
                            r = e.aliases || Object.create(null),
                            o = {};

                        function s(e) {
                            o = c(i[e] || r[e], o)
                        }
                        return s(t), n.forEach(s), c(e, o)
                    }(e, r, o)), n.push(r))
                }
                return n
            }
            let h = {
                provider: "",
                aliases: {},
                not_found: {},
                ...s
            };

            function p(e, t) {
                for (let n in t)
                    if (n in e && typeof e[n] != typeof t[n]) return !1;
                return !0
            }

            function f(e) {
                if ("object" != typeof e || null === e || "string" != typeof e.prefix || !e.icons || "object" != typeof e.icons || !p(e, h)) return null;
                let t = e.icons;
                for (let e in t) {
                    let n = t[e];
                    if (!e || "string" != typeof n.body || !p(n, u)) return null
                }
                let n = e.aliases || Object.create(null);
                for (let e in n) {
                    let i = n[e],
                        r = i.parent;
                    if (!e || "string" != typeof r || !t[r] && !n[r] || !p(i, u)) return null
                }
                return e
            }
            let m = /^[a-z0-9]+(-[a-z0-9]+)*$/,
                g = (e, t, n, i = "") => {
                    let r = e.split(":");
                    if ("@" === e.slice(0, 1)) {
                        if (r.length < 2 || r.length > 3) return null;
                        i = r.shift().slice(1)
                    }
                    if (r.length > 3 || !r.length) return null;
                    if (r.length > 1) {
                        let e = r.pop(),
                            n = r.pop(),
                            o = {
                                provider: r.length > 0 ? r[0] : i,
                                prefix: n,
                                name: e
                            };
                        return t && !v(o) ? null : o
                    }
                    let o = r[0],
                        s = o.split("-");
                    if (s.length > 1) {
                        let e = {
                            provider: i,
                            prefix: s.shift(),
                            name: s.join("-")
                        };
                        return t && !v(e) ? null : e
                    }
                    if (n && "" === i) {
                        let e = {
                            provider: i,
                            prefix: "",
                            name: o
                        };
                        return t && !v(e, n) ? null : e
                    }
                    return null
                },
                v = (e, t) => !!e && !!((t && "" === e.prefix || e.prefix) && e.name),
                A = Object.create(null);

            function y(e, t) {
                let n = A[e] || (A[e] = Object.create(null));
                return n[t] || (n[t] = {
                    provider: e,
                    prefix: t,
                    icons: Object.create(null),
                    missing: new Set
                })
            }

            function w(e, t) {
                return f(t) ? d(t, (t, n) => {
                    n ? e.icons[t] = n : e.missing.add(t)
                }) : []
            }
            let E = !1;

            function b(e) {
                return "boolean" == typeof e && (E = e), E
            }

            function S(e) {
                let t = "string" == typeof e ? g(e, !0, E) : e;
                if (t) {
                    let e = y(t.provider, t.prefix),
                        n = t.name;
                    return e.icons[n] || (e.missing.has(n) ? null : void 0)
                }
            }
            let x = Object.freeze({
                    width: null,
                    height: null
                }),
                C = Object.freeze({ ...x,
                    ...a
                }),
                T = /(-?[0-9.]*[0-9]+[0-9.]*)/g,
                L = /^-?[0-9.]*[0-9]+[0-9.]*$/g;

            function _(e, t, n) {
                if (1 === t) return e;
                if (n = n || 100, "number" == typeof e) return Math.ceil(e * t * n) / n;
                if ("string" != typeof e) return e;
                let i = e.split(T);
                if (null === i || !i.length) return e;
                let r = [],
                    o = i.shift(),
                    s = L.test(o);
                for (;;) {
                    if (s) {
                        let e = parseFloat(o);
                        isNaN(e) ? r.push(o) : r.push(Math.ceil(e * t * n) / n)
                    } else r.push(o);
                    if (void 0 === (o = i.shift())) return r.join("");
                    s = !s
                }
            }
            let M = e => "unset" === e || "undefined" === e || "none" === e,
                P = /\sid="(\S+)"/g,
                O = "IconifyId" + Date.now().toString(16) + (16777216 * Math.random() | 0).toString(16),
                k = 0,
                R = Object.create(null);

            function I(e) {
                return R[e] || R[""]
            }

            function D(e) {
                let t;
                if ("string" == typeof e.resources) t = [e.resources];
                else if (!((t = e.resources) instanceof Array) || !t.length) return null;
                let n = {
                    resources: t,
                    path: e.path || "/",
                    maxURL: e.maxURL || 500,
                    rotate: e.rotate || 750,
                    timeout: e.timeout || 5e3,
                    random: !0 === e.random,
                    index: e.index || 0,
                    dataAfterTimeout: !1 !== e.dataAfterTimeout
                };
                return n
            }
            let N = Object.create(null),
                F = ["https://api.simplesvg.com", "https://api.unisvg.com"],
                j = [];
            for (; F.length > 0;) 1 === F.length ? j.push(F.shift()) : Math.random() > .5 ? j.push(F.shift()) : j.push(F.pop());
            N[""] = D({
                resources: ["https://api.iconify.design"].concat(j)
            });
            let B = (() => {
                    let e;
                    try {
                        if (e = fetch, "function" == typeof e) return e
                    } catch (e) {}
                })(),
                U = (e, t, n) => {
                    let i = [],
                        r = function(e, t) {
                            let n;
                            let i = N[e];
                            if (!i) return 0;
                            if (i.maxURL) {
                                let e = 0;
                                i.resources.forEach(t => {
                                    e = Math.max(e, t.length)
                                }), n = i.maxURL - e - i.path.length - (t + ".json?icons=").length
                            } else n = 0;
                            return n
                        }(e, t),
                        o = "icons",
                        s = {
                            type: o,
                            provider: e,
                            prefix: t,
                            icons: []
                        },
                        a = 0;
                    return n.forEach((n, l) => {
                        (a += n.length + 1) >= r && l > 0 && (i.push(s), s = {
                            type: o,
                            provider: e,
                            prefix: t,
                            icons: []
                        }, a = n.length), s.icons.push(n)
                    }), i.push(s), i
                },
                z = (e, t, n) => {
                    if (!B) {
                        n("abort", 424);
                        return
                    }
                    let i = function(e) {
                        if ("string" == typeof e) {
                            let t = N[e];
                            if (t) return t.path
                        }
                        return "/"
                    }(t.provider);
                    switch (t.type) {
                        case "icons":
                            {
                                let e = t.prefix,
                                    n = t.icons,
                                    r = n.join(","),
                                    o = new URLSearchParams({
                                        icons: r
                                    });i += e + ".json?" + o.toString();
                                break
                            }
                        case "custom":
                            {
                                let e = t.uri;i += "/" === e.slice(0, 1) ? e.slice(1) : e;
                                break
                            }
                        default:
                            n("abort", 400);
                            return
                    }
                    let r = 503;
                    B(e + i).then(e => {
                        let t = e.status;
                        if (200 !== t) {
                            setTimeout(() => {
                                n(404 === t ? "abort" : "next", t)
                            });
                            return
                        }
                        return r = 501, e.json()
                    }).then(e => {
                        if ("object" != typeof e || null === e) {
                            setTimeout(() => {
                                404 === e ? n("abort", e) : n("next", r)
                            });
                            return
                        }
                        setTimeout(() => {
                            n("success", e)
                        })
                    }).catch(() => {
                        n("next", r)
                    })
                };

            function W(e, t) {
                e.forEach(e => {
                    let n = e.loaderCallbacks;
                    n && (e.loaderCallbacks = n.filter(e => e.id !== t))
                })
            }
            let Y = 0;
            var V = {
                resources: [],
                index: 0,
                timeout: 2e3,
                rotate: 750,
                random: !1,
                dataAfterTimeout: !1
            };

            function H(e) {
                let t = { ...V,
                        ...e
                    },
                    n = [];

                function i() {
                    n = n.filter(e => "pending" === e().status)
                }
                return {
                    query: function(e, r, o) {
                        let s = function(e, t, n, i) {
                            let r, o;
                            let s = e.resources.length,
                                a = e.random ? Math.floor(Math.random() * s) : e.index;
                            if (e.random) {
                                let t = e.resources.slice(0);
                                for (r = []; t.length > 1;) {
                                    let e = Math.floor(Math.random() * t.length);
                                    r.push(t[e]), t = t.slice(0, e).concat(t.slice(e + 1))
                                }
                                r = r.concat(t)
                            } else r = e.resources.slice(a).concat(e.resources.slice(0, a));
                            let l = Date.now(),
                                u = "pending",
                                c = 0,
                                d = null,
                                h = [],
                                p = [];

                            function f() {
                                d && (clearTimeout(d), d = null)
                            }

                            function m() {
                                "pending" === u && (u = "aborted"), f(), h.forEach(e => {
                                    "pending" === e.status && (e.status = "aborted")
                                }), h = []
                            }

                            function g(e, t) {
                                t && (p = []), "function" == typeof e && p.push(e)
                            }

                            function v() {
                                u = "failed", p.forEach(e => {
                                    e(void 0, o)
                                })
                            }

                            function A() {
                                h.forEach(e => {
                                    "pending" === e.status && (e.status = "aborted")
                                }), h = []
                            }
                            return "function" == typeof i && p.push(i), setTimeout(function i() {
                                    if ("pending" !== u) return;
                                    f();
                                    let s = r.shift();
                                    if (void 0 === s) {
                                        if (h.length) {
                                            d = setTimeout(() => {
                                                f(), "pending" === u && (A(), v())
                                            }, e.timeout);
                                            return
                                        }
                                        v();
                                        return
                                    }
                                    let a = {
                                        status: "pending",
                                        resource: s,
                                        callback: (t, n) => {
                                            ! function(t, n, s) {
                                                let a = "success" !== n;
                                                switch (h = h.filter(e => e !== t), u) {
                                                    case "pending":
                                                        break;
                                                    case "failed":
                                                        if (a || !e.dataAfterTimeout) return;
                                                        break;
                                                    default:
                                                        return
                                                }
                                                if ("abort" === n) {
                                                    o = s, v();
                                                    return
                                                }
                                                if (a) {
                                                    o = s, h.length || (r.length ? i() : v());
                                                    return
                                                }
                                                if (f(), A(), !e.random) {
                                                    let n = e.resources.indexOf(t.resource); - 1 !== n && n !== e.index && (e.index = n)
                                                }
                                                u = "completed", p.forEach(e => {
                                                    e(s)
                                                })
                                            }(a, t, n)
                                        }
                                    };
                                    h.push(a), c++, d = setTimeout(i, e.rotate), n(s, t, a.callback)
                                }),
                                function() {
                                    return {
                                        startTime: l,
                                        payload: t,
                                        status: u,
                                        queriesSent: c,
                                        queriesPending: h.length,
                                        subscribe: g,
                                        abort: m
                                    }
                                }
                        }(t, e, r, (e, t) => {
                            i(), o && o(e, t)
                        });
                        return n.push(s), s
                    },
                    find: function(e) {
                        return n.find(t => e(t)) || null
                    },
                    setIndex: e => {
                        t.index = e
                    },
                    getIndex: () => t.index,
                    cleanup: i
                }
            }
            let X = Object.create(null);

            function J() {}

            function $(e, t, n) {
                var i;

                function r() {
                    let n = e.pendingIcons;
                    t.forEach(t => {
                        n && n.delete(t), e.icons[t] || e.missing.add(t)
                    })
                }
                if (n && "object" == typeof n) try {
                    let t = w(e, n);
                    if (!t.length) {
                        r();
                        return
                    }
                } catch (e) {
                    console.error(e)
                }
                r(), (i = e).iconsLoaderFlag || (i.iconsLoaderFlag = !0, setTimeout(() => {
                    var e;
                    i.iconsLoaderFlag = !1, (e = i).pendingCallbacksFlag || (e.pendingCallbacksFlag = !0, setTimeout(() => {
                        e.pendingCallbacksFlag = !1;
                        let t = e.loaderCallbacks ? e.loaderCallbacks.slice(0) : [];
                        if (!t.length) return;
                        let n = !1,
                            i = e.provider,
                            r = e.prefix;
                        t.forEach(t => {
                            let o = t.icons,
                                s = o.pending.length;
                            o.pending = o.pending.filter(t => {
                                if (t.prefix !== r) return !0;
                                let s = t.name;
                                if (e.icons[s]) o.loaded.push({
                                    provider: i,
                                    prefix: r,
                                    name: s
                                });
                                else {
                                    if (!e.missing.has(s)) return n = !0, !0;
                                    o.missing.push({
                                        provider: i,
                                        prefix: r,
                                        name: s
                                    })
                                }
                                return !1
                            }), o.pending.length !== s && (n || W([e], t.id), t.callback(o.loaded.slice(0), o.missing.slice(0), o.pending.slice(0), t.abort))
                        })
                    }))
                }))
            }

            function Q(e, t) {
                e instanceof Promise ? e.then(e => {
                    t(e)
                }).catch(() => {
                    t(null)
                }) : t(e)
            }
            let G = (e, t) => {
                    let n, i;
                    let r = function(e, t = !0, n = !1) {
                            let i = [];
                            return e.forEach(e => {
                                let r = "string" == typeof e ? g(e, t, n) : e;
                                r && i.push(r)
                            }), i
                        }(e, !0, b()),
                        o = function(e) {
                            let t = {
                                    loaded: [],
                                    missing: [],
                                    pending: []
                                },
                                n = Object.create(null);
                            e.sort((e, t) => e.provider !== t.provider ? e.provider.localeCompare(t.provider) : e.prefix !== t.prefix ? e.prefix.localeCompare(t.prefix) : e.name.localeCompare(t.name));
                            let i = {
                                provider: "",
                                prefix: "",
                                name: ""
                            };
                            return e.forEach(e => {
                                if (i.name === e.name && i.prefix === e.prefix && i.provider === e.provider) return;
                                i = e;
                                let r = e.provider,
                                    o = e.prefix,
                                    s = e.name,
                                    a = n[r] || (n[r] = Object.create(null)),
                                    l = a[o] || (a[o] = y(r, o));
                                (s in l.icons ? t.loaded : "" === o || l.missing.has(s) ? t.missing : t.pending).push({
                                    provider: r,
                                    prefix: o,
                                    name: s
                                })
                            }), t
                        }(r);
                    if (!o.pending.length) {
                        let e = !0;
                        return t && setTimeout(() => {
                            e && t(o.loaded, o.missing, o.pending, J)
                        }), () => {
                            e = !1
                        }
                    }
                    let s = Object.create(null),
                        a = [];
                    return o.pending.forEach(e => {
                        let {
                            provider: t,
                            prefix: r
                        } = e;
                        if (r === i && t === n) return;
                        n = t, i = r, a.push(y(t, r));
                        let o = s[t] || (s[t] = Object.create(null));
                        o[r] || (o[r] = [])
                    }), o.pending.forEach(e => {
                        let {
                            provider: t,
                            prefix: n,
                            name: i
                        } = e, r = y(t, n), o = r.pendingIcons || (r.pendingIcons = new Set);
                        o.has(i) || (o.add(i), s[t][n].push(i))
                    }), a.forEach(e => {
                        let t = s[e.provider][e.prefix];
                        if (t.length) {
                            var n;
                            (n = e).iconsToLoad ? n.iconsToLoad = n.iconsToLoad.concat(t).sort() : n.iconsToLoad = t, n.iconsQueueFlag || (n.iconsQueueFlag = !0, setTimeout(() => {
                                n.iconsQueueFlag = !1;
                                let {
                                    provider: e,
                                    prefix: t
                                } = n, i = n.iconsToLoad;
                                if (delete n.iconsToLoad, !i || !i.length) return;
                                let r = n.loadIcon;
                                if (n.loadIcons && (i.length > 1 || !r)) {
                                    Q(n.loadIcons(i, t, e), e => {
                                        $(n, i, e)
                                    });
                                    return
                                }
                                if (r) {
                                    i.forEach(i => {
                                        let o = r(i, t, e);
                                        Q(o, e => {
                                            $(n, [i], e ? {
                                                prefix: t,
                                                icons: {
                                                    [i]: e
                                                }
                                            } : null)
                                        })
                                    });
                                    return
                                }
                                let {
                                    valid: o,
                                    invalid: s
                                } = function(e) {
                                    let t = [],
                                        n = [];
                                    return e.forEach(e => {
                                        (e.match(m) ? t : n).push(e)
                                    }), {
                                        valid: t,
                                        invalid: n
                                    }
                                }(i);
                                if (s.length && $(n, s, null), !o.length) return;
                                let a = t.match(m) ? I(e) : null;
                                if (!a) {
                                    $(n, o, null);
                                    return
                                }
                                let l = a.prepare(e, t, o);
                                l.forEach(t => {
                                    ! function(e, t, n) {
                                        let i, r;
                                        if ("string" == typeof e) {
                                            let t = I(e);
                                            if (!t) return n(void 0, 424);
                                            r = t.send;
                                            let o = function(e) {
                                                if (!X[e]) {
                                                    let t = N[e];
                                                    if (!t) return;
                                                    let n = H(t);
                                                    X[e] = {
                                                        config: t,
                                                        redundancy: n
                                                    }
                                                }
                                                return X[e]
                                            }(e);
                                            o && (i = o.redundancy)
                                        } else {
                                            let t = D(e);
                                            if (t) {
                                                i = H(t);
                                                let n = e.resources ? e.resources[0] : "",
                                                    o = I(n);
                                                o && (r = o.send)
                                            }
                                        }
                                        i && r ? i.query(t, r, n)().abort : n(void 0, 424)
                                    }(e, t, e => {
                                        $(n, t.icons, e)
                                    })
                                })
                            }))
                        }
                    }), t ? function(e, t, n) {
                        let i = Y++,
                            r = W.bind(null, n, i);
                        if (!t.pending.length) return r;
                        let o = {
                            id: i,
                            icons: t,
                            callback: e,
                            abort: r
                        };
                        return n.forEach(e => {
                            (e.loaderCallbacks || (e.loaderCallbacks = [])).push(o)
                        }), r
                    }(t, o, a) : J
                },
                Z = /[\s,]+/,
                q = { ...C,
                    inline: !1
                },
                K = {
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    "aria-hidden": !0,
                    role: "img"
                },
                ee = {
                    display: "inline-block"
                },
                et = {
                    backgroundColor: "currentColor"
                },
                en = {
                    backgroundColor: "transparent"
                },
                ei = {
                    Image: "var(--svg)",
                    Repeat: "no-repeat",
                    Size: "100% 100%"
                },
                er = {
                    WebkitMask: et,
                    mask: et,
                    background: en
                };
            for (let e in er) {
                let t = er[e];
                for (let n in ei) t[e + n] = ei[n]
            }
            let eo = { ...q,
                inline: !0
            };

            function es(e) {
                return e + (e.match(/^[-0-9.]+$/) ? "px" : "")
            }
            let ea = (e, t, n) => {
                let r = t.inline ? eo : q,
                    s = function(e, t) {
                        let n = { ...e
                        };
                        for (let e in t) {
                            let i = t[e],
                                r = typeof i;
                            e in x ? (null === i || i && ("string" === r || "number" === r)) && (n[e] = i) : r === typeof n[e] && (n[e] = "rotate" === e ? i % 4 : i)
                        }
                        return n
                    }(r, t),
                    a = t.mode || "svg",
                    u = {},
                    c = t.style || {},
                    d = { ..."svg" === a ? K : {}
                    };
                if (n) {
                    let e = g(n, !1, !0);
                    if (e) {
                        let t = ["iconify"];
                        for (let n of ["provider", "prefix"]) e[n] && t.push("iconify--" + e[n]);
                        d.className = t.join(" ")
                    }
                }
                for (let e in t) {
                    let n = t[e];
                    if (void 0 !== n) switch (e) {
                        case "icon":
                        case "style":
                        case "children":
                        case "onLoad":
                        case "mode":
                        case "ssr":
                            break;
                        case "_ref":
                            d.ref = n;
                            break;
                        case "className":
                            d[e] = (d[e] ? d[e] + " " : "") + n;
                            break;
                        case "inline":
                        case "hFlip":
                        case "vFlip":
                            s[e] = !0 === n || "true" === n || 1 === n;
                            break;
                        case "flip":
                            "string" == typeof n && function(e, t) {
                                t.split(Z).forEach(t => {
                                    let n = t.trim();
                                    switch (n) {
                                        case "horizontal":
                                            e.hFlip = !0;
                                            break;
                                        case "vertical":
                                            e.vFlip = !0
                                    }
                                })
                            }(s, n);
                            break;
                        case "color":
                            u.color = n;
                            break;
                        case "rotate":
                            "string" == typeof n ? s[e] = function(e, t = 0) {
                                let n = e.replace(/^-?[0-9.]*/, "");

                                function i(e) {
                                    for (; e < 0;) e += 4;
                                    return e % 4
                                }
                                if ("" === n) {
                                    let t = parseInt(e);
                                    return isNaN(t) ? 0 : i(t)
                                }
                                if (n !== e) {
                                    let t = 0;
                                    switch (n) {
                                        case "%":
                                            t = 25;
                                            break;
                                        case "deg":
                                            t = 90
                                    }
                                    if (t) {
                                        let r = parseFloat(e.slice(0, e.length - n.length));
                                        return isNaN(r) ? 0 : (r /= t) % 1 == 0 ? i(r) : 0
                                    }
                                }
                                return t
                            }(n) : "number" == typeof n && (s[e] = n);
                            break;
                        case "ariaHidden":
                        case "aria-hidden":
                            !0 !== n && "true" !== n && delete d["aria-hidden"];
                            break;
                        default:
                            void 0 === r[e] && (d[e] = n)
                    }
                }
                let h = function(e, t) {
                        let n, i;
                        let r = { ...l,
                                ...e
                            },
                            o = { ...C,
                                ...t
                            },
                            s = {
                                left: r.left,
                                top: r.top,
                                width: r.width,
                                height: r.height
                            },
                            a = r.body;
                        [r, o].forEach(e => {
                            let t;
                            let n = [],
                                i = e.hFlip,
                                r = e.vFlip,
                                o = e.rotate;
                            switch (i ? r ? o += 2 : (n.push("translate(" + (s.width + s.left).toString() + " " + (0 - s.top).toString() + ")"), n.push("scale(-1 1)"), s.top = s.left = 0) : r && (n.push("translate(" + (0 - s.left).toString() + " " + (s.height + s.top).toString() + ")"), n.push("scale(1 -1)"), s.top = s.left = 0), o < 0 && (o -= 4 * Math.floor(o / 4)), o %= 4) {
                                case 1:
                                    n.unshift("rotate(90 " + (t = s.height / 2 + s.top).toString() + " " + t.toString() + ")");
                                    break;
                                case 2:
                                    n.unshift("rotate(180 " + (s.width / 2 + s.left).toString() + " " + (s.height / 2 + s.top).toString() + ")");
                                    break;
                                case 3:
                                    n.unshift("rotate(-90 " + (t = s.width / 2 + s.left).toString() + " " + t.toString() + ")")
                            }
                            o % 2 == 1 && (s.left !== s.top && (t = s.left, s.left = s.top, s.top = t), s.width !== s.height && (t = s.width, s.width = s.height, s.height = t)), n.length && (a = function(e, t, n) {
                                var i, r;
                                let o = function(e, t = "defs") {
                                    let n = "",
                                        i = e.indexOf("<" + t);
                                    for (; i >= 0;) {
                                        let r = e.indexOf(">", i),
                                            o = e.indexOf("</" + t);
                                        if (-1 === r || -1 === o) break;
                                        let s = e.indexOf(">", o);
                                        if (-1 === s) break;
                                        n += e.slice(r + 1, o).trim(), e = e.slice(0, i).trim() + e.slice(s + 1)
                                    }
                                    return {
                                        defs: n,
                                        content: e
                                    }
                                }(e);
                                return i = o.defs, r = t + o.content + n, i ? "<defs>" + i + "</defs>" + r : r
                            }(a, '<g transform="' + n.join(" ") + '">', "</g>"))
                        });
                        let u = o.width,
                            c = o.height,
                            d = s.width,
                            h = s.height;
                        null === u ? n = _(i = null === c ? "1em" : "auto" === c ? h : c, d / h) : (n = "auto" === u ? d : u, i = null === c ? _(n, h / d) : "auto" === c ? h : c);
                        let p = {},
                            f = (e, t) => {
                                M(t) || (p[e] = t.toString())
                            };
                        f("width", n), f("height", i);
                        let m = [s.left, s.top, d, h];
                        return p.viewBox = m.join(" "), {
                            attributes: p,
                            viewBox: m,
                            body: a
                        }
                    }(e, s),
                    p = h.attributes;
                if (s.inline && (u.verticalAlign = "-0.125em"), "svg" === a) {
                    var f;
                    d.style = { ...u,
                        ...c
                    }, Object.assign(d, p);
                    let e = 0,
                        n = t.id;
                    return "string" == typeof n && (n = n.replace(/-/g, "_")), d.dangerouslySetInnerHTML = {
                        __html: (f = function(e, t = O) {
                            let n;
                            let i = [];
                            for (; n = P.exec(e);) i.push(n[1]);
                            if (!i.length) return e;
                            let r = "suffix" + (16777216 * Math.random() | Date.now()).toString(16);
                            return i.forEach(n => {
                                let i = "function" == typeof t ? t(n) : t + (k++).toString(),
                                    o = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                                e = e.replace(RegExp('([#;"])(' + o + ')([")]|\\.[a-z])', "g"), "$1" + i + r + "$3")
                            }), e = e.replace(RegExp(r, "g"), "")
                        }(h.body, n ? () => n + "ID" + e++ : "iconifyReact"), void 0 === i && function() {
                            try {
                                i = window.trustedTypes.createPolicy("iconify", {
                                    createHTML: e => e
                                })
                            } catch (e) {
                                i = null
                            }
                        }(), i ? i.createHTML(f) : f)
                    }, (0, o.createElement)("svg", d)
                }
                let {
                    body: m,
                    width: v,
                    height: A
                } = e, y = "mask" === a || "bg" !== a && -1 !== m.indexOf("currentColor"), w = function(e, t) {
                    let n = -1 === e.indexOf("xlink:") ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
                    for (let e in t) n += " " + e + '="' + t[e] + '"';
                    return '<svg xmlns="http://www.w3.org/2000/svg"' + n + ">" + e + "</svg>"
                }(m, { ...p,
                    width: v + "",
                    height: A + ""
                });
                return d.style = { ...u,
                    "--svg": 'url("data:image/svg+xml,' + w.replace(/"/g, "'").replace(/%/g, "%25").replace(/#/g, "%23").replace(/</g, "%3C").replace(/>/g, "%3E").replace(/\s+/g, " ") + '")',
                    width: es(p.width),
                    height: es(p.height),
                    ...ee,
                    ...y ? et : en,
                    ...c
                }, (0, o.createElement)("span", d)
            };
            if (b(!0), R[""] = {
                    prepare: U,
                    send: z
                }, "undefined" != typeof document && "undefined" != typeof window) {
                let e = window;
                if (void 0 !== e.IconifyPreload) {
                    let t = e.IconifyPreload,
                        n = "Invalid IconifyPreload syntax.";
                    "object" == typeof t && null !== t && (t instanceof Array ? t : [t]).forEach(e => {
                        try {
                            ("object" != typeof e || null === e || e instanceof Array || "object" != typeof e.icons || "string" != typeof e.prefix || ! function(e, t) {
                                if ("object" != typeof e) return !1;
                                if ("string" != typeof t && (t = e.provider || ""), E && !t && !e.prefix) {
                                    let t = !1;
                                    return f(e) && (e.prefix = "", d(e, (e, n) => {
                                        (function(e, t) {
                                            let n = g(e, !0, E);
                                            if (!n) return !1;
                                            let i = y(n.provider, n.prefix);
                                            return t ? function(e, t, n) {
                                                try {
                                                    if ("string" == typeof n.body) return e.icons[t] = { ...n
                                                    }, !0
                                                } catch (e) {}
                                                return !1
                                            }(i, n.name, t) : (i.missing.add(n.name), !0)
                                        })(e, n) && (t = !0)
                                    })), t
                                }
                                let n = e.prefix;
                                if (!v({
                                        prefix: n,
                                        name: "a"
                                    })) return !1;
                                let i = y(t, n);
                                return !!w(i, e)
                            }(e)) && console.error(n)
                        } catch (e) {
                            console.error(n)
                        }
                    })
                }
                if (void 0 !== e.IconifyProviders) {
                    let t = e.IconifyProviders;
                    if ("object" == typeof t && null !== t)
                        for (let e in t) {
                            let n = "IconifyProviders[" + e + "] is invalid.";
                            try {
                                let i = t[e];
                                if ("object" != typeof i || !i || void 0 === i.resources) continue;
                                ! function(e, t) {
                                    let n = D(t);
                                    return null !== n && (N[e] = n, !0)
                                }(e, i) && console.error(n)
                            } catch (e) {
                                console.error(n)
                            }
                        }
                }
            }

            function el(e) {
                let [t, n] = (0, o.useState)(!!e.ssr), [i, r] = (0, o.useState)({}), [s, a] = (0, o.useState)(function(t) {
                    if (t) {
                        let t = e.icon;
                        if ("object" == typeof t) return {
                            name: "",
                            data: t
                        };
                        let n = S(t);
                        if (n) return {
                            name: t,
                            data: n
                        }
                    }
                    return {
                        name: ""
                    }
                }(!!e.ssr));

                function u() {
                    let e = i.callback;
                    e && (e(), r({}))
                }

                function c(e) {
                    if (JSON.stringify(s) !== JSON.stringify(e)) return u(), a(e), !0
                }(0, o.useEffect)(() => (n(!0), u), []), (0, o.useEffect)(() => {
                    t && function t() {
                        var n;
                        let i = e.icon;
                        if ("object" == typeof i) {
                            c({
                                name: "",
                                data: i
                            });
                            return
                        }
                        let o = S(i);
                        if (c({
                                name: i,
                                data: o
                            })) {
                            if (void 0 === o) {
                                let e = G([i], t);
                                r({
                                    callback: e
                                })
                            } else o && (null === (n = e.onLoad) || void 0 === n || n.call(e, i))
                        }
                    }()
                }, [e.icon, t]);
                let {
                    name: d,
                    data: h
                } = s;
                return h ? ea({ ...l,
                    ...h
                }, e, d) : e.children ? e.children : e.fallback ? e.fallback : (0, o.createElement)("span", {})
            }
            let eu = (0, o.forwardRef)((e, t) => el({ ...e,
                _ref: t
            }));

            function ec() {
                return (ec = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var i in n)({}).hasOwnProperty.call(n, i) && (e[i] = n[i])
                    }
                    return e
                }).apply(null, arguments)
            }(0, o.forwardRef)((e, t) => el({
                inline: !0,
                ...e,
                _ref: t
            }));
            let ed = e => {
                    switch (e) {
                        case "stacked":
                        default:
                            return "rhap_stacked";
                        case "stacked-reverse":
                            return "rhap_stacked-reverse";
                        case "horizontal":
                            return "rhap_horizontal";
                        case "horizontal-reverse":
                            return "rhap_horizontal-reverse"
                    }
                },
                eh = e => e instanceof MouseEvent ? e.clientX : e.touches[0].clientX,
                ep = e => e > 9 ? e.toString() : `0${e}`,
                ef = (e, t, n) => {
                    if (!isFinite(e)) return null;
                    let i = Math.floor(e / 60),
                        r = ep(i),
                        o = ep(Math.floor(e % 60)),
                        s = ep(Math.floor(i % 60)),
                        a = `${r}:${o}`,
                        l = `${Math.floor(i/60)}:${s}:${o}`;
                    return "auto" === n ? t >= 3600 ? l : a : "mm:ss" === n ? a : "hh:mm:ss" === n ? l : void 0
                };

            function em(e, t) {
                let n = !1;
                return i => {
                    n || (e(i), n = !0, setTimeout(() => n = !1, t))
                }
            }
            class eg extends o.Component {
                timeOnMouseMove = 0;
                hasAddedAudioEventListener = !1;
                state = {
                    isDraggingProgress: !1,
                    currentTimePos: "0%",
                    hasDownloadProgressAnimation: !1,
                    downloadProgressArr: [],
                    waitingForSeekCallback: !1
                };
                getDuration() {
                    let {
                        audio: e,
                        srcDuration: t
                    } = this.props;
                    return void 0 === t ? e.duration : t
                }
                getCurrentProgress = e => {
                    let {
                        audio: t,
                        progressBar: n
                    } = this.props, i = 0 !== t.src.indexOf("blob:") && void 0 === this.props.srcDuration;
                    if (i && (!t.src || !isFinite(t.currentTime) || !n.current)) return {
                        currentTime: 0,
                        currentTimePos: "0%"
                    };
                    let r = n.current.getBoundingClientRect(),
                        o = r.width,
                        s = eh(e) - r.left;
                    s < 0 ? s = 0 : s > o && (s = o);
                    let a = this.getDuration(),
                        l = a * s / o;
                    return {
                        currentTime: l,
                        currentTimePos: `${(s/o*100).toFixed(2)}%`
                    }
                };
                handleContextMenu = e => {
                    e.preventDefault()
                };
                handleMouseDownOrTouchStartProgressBar = e => {
                    e.stopPropagation();
                    let {
                        currentTime: t,
                        currentTimePos: n
                    } = this.getCurrentProgress(e.nativeEvent);
                    isFinite(t) && (this.timeOnMouseMove = t, this.setState({
                        isDraggingProgress: !0,
                        currentTimePos: n
                    }), e.nativeEvent instanceof MouseEvent ? (window.addEventListener("mousemove", this.handleWindowMouseOrTouchMove), window.addEventListener("mouseup", this.handleWindowMouseOrTouchUp)) : (window.addEventListener("touchmove", this.handleWindowMouseOrTouchMove), window.addEventListener("touchend", this.handleWindowMouseOrTouchUp)))
                };
                handleWindowMouseOrTouchMove = e => {
                    e instanceof MouseEvent && e.preventDefault(), e.stopPropagation();
                    let t = window.getSelection();
                    t && "Range" === t.type && t.empty();
                    let {
                        isDraggingProgress: n
                    } = this.state;
                    if (n) {
                        let {
                            currentTime: t,
                            currentTimePos: n
                        } = this.getCurrentProgress(e);
                        this.timeOnMouseMove = t, this.setState({
                            currentTimePos: n
                        })
                    }
                };
                handleWindowMouseOrTouchUp = e => {
                    e.stopPropagation();
                    let t = this.timeOnMouseMove,
                        {
                            audio: n,
                            onChangeCurrentTimeError: i,
                            onSeek: r
                        } = this.props;
                    if (r) this.setState({
                        isDraggingProgress: !1,
                        waitingForSeekCallback: !0
                    }, () => {
                        r(n, t).then(() => this.setState({
                            waitingForSeekCallback: !1
                        }), e => {
                            throw Error(e)
                        })
                    });
                    else {
                        let e = {
                            isDraggingProgress: !1
                        };
                        if (n.readyState === n.HAVE_NOTHING || n.readyState === n.HAVE_METADATA || !isFinite(t)) try {
                            n.load()
                        } catch (t) {
                            return e.currentTimePos = "0%", i && i(t)
                        }
                        n.currentTime = t, this.setState(e)
                    }
                    e instanceof MouseEvent ? (window.removeEventListener("mousemove", this.handleWindowMouseOrTouchMove), window.removeEventListener("mouseup", this.handleWindowMouseOrTouchUp)) : (window.removeEventListener("touchmove", this.handleWindowMouseOrTouchMove), window.removeEventListener("touchend", this.handleWindowMouseOrTouchUp))
                };
                handleAudioTimeUpdate = em(e => {
                    let {
                        isDraggingProgress: t
                    } = this.state, n = e.target;
                    if (t || !0 === this.state.waitingForSeekCallback) return;
                    let {
                        currentTime: i
                    } = n, r = this.getDuration();
                    this.setState({
                        currentTimePos: `${(i/r*100||0).toFixed(2)}%`
                    })
                }, this.props.progressUpdateInterval);
                handleAudioDownloadProgressUpdate = e => {
                    let t = e.target,
                        n = this.getDuration(),
                        i = [];
                    for (let e = 0; e < t.buffered.length; e++) {
                        let r = t.buffered.start(e),
                            o = t.buffered.end(e);
                        i.push({
                            left: `${Math.round(100/n*r)||0}%`,
                            width: `${Math.round(100/n*(o-r))||0}%`
                        })
                    }
                    clearTimeout(this.downloadProgressAnimationTimer), this.setState({
                        downloadProgressArr: i,
                        hasDownloadProgressAnimation: !0
                    }), this.downloadProgressAnimationTimer = setTimeout(() => {
                        this.setState({
                            hasDownloadProgressAnimation: !1
                        })
                    }, 200)
                };
                initialize() {
                    let {
                        audio: e
                    } = this.props;
                    e && !this.hasAddedAudioEventListener && (this.audio = e, this.hasAddedAudioEventListener = !0, e.addEventListener("timeupdate", this.handleAudioTimeUpdate), e.addEventListener("progress", this.handleAudioDownloadProgressUpdate))
                }
                componentDidMount() {
                    this.initialize()
                }
                componentDidUpdate() {
                    this.initialize()
                }
                componentWillUnmount() {
                    this.audio && this.hasAddedAudioEventListener && (this.audio.removeEventListener("timeupdate", this.handleAudioTimeUpdate), this.audio.removeEventListener("progress", this.handleAudioDownloadProgressUpdate)), clearTimeout(this.downloadProgressAnimationTimer)
                }
                render() {
                    let {
                        showDownloadProgress: e,
                        showFilledProgress: t,
                        progressBar: n,
                        i18nProgressBar: i
                    } = this.props, {
                        currentTimePos: r,
                        downloadProgressArr: s,
                        hasDownloadProgressAnimation: a
                    } = this.state;
                    return o.createElement("div", {
                        className: "rhap_progress-container",
                        ref: n,
                        "aria-label": i,
                        role: "progressbar",
                        "aria-valuemin": 0,
                        "aria-valuemax": 100,
                        "aria-valuenow": Number(r.split("%")[0]),
                        tabIndex: 0,
                        onMouseDown: this.handleMouseDownOrTouchStartProgressBar,
                        onTouchStart: this.handleMouseDownOrTouchStartProgressBar,
                        onContextMenu: this.handleContextMenu
                    }, o.createElement("div", {
                        className: `rhap_progress-bar ${e?"rhap_progress-bar-show-download":""}`
                    }, o.createElement("div", {
                        className: "rhap_progress-indicator",
                        style: {
                            left: r
                        }
                    }), t && o.createElement("div", {
                        className: "rhap_progress-filled",
                        style: {
                            width: r
                        }
                    }), e && s.map((e, t) => {
                        let {
                            left: n,
                            width: i
                        } = e;
                        return o.createElement("div", {
                            key: t,
                            className: "rhap_download-progress",
                            style: {
                                left: n,
                                width: i,
                                transitionDuration: a ? ".2s" : "0s"
                            }
                        })
                    })))
                }
            }
            let ev = (e, t) => o.createElement(eg, ec({}, e, {
                progressBar: t
            }));
            var eA = (0, o.forwardRef)(ev);
            class ey extends o.PureComponent {
                hasAddedAudioEventListener = !1;
                constructor(e) {
                    super(e);
                    let {
                        audio: t,
                        defaultCurrentTime: n,
                        isLeftTime: i,
                        timeFormat: r
                    } = e, o = n;
                    t && (o = ef(i ? t.duration - t.currentTime : t.currentTime, t.duration, r)), this.state = {
                        currentTime: o
                    }
                }
                state = {
                    currentTime: this.props.defaultCurrentTime
                };
                handleAudioCurrentTimeChange = e => {
                    let t = e.target,
                        {
                            isLeftTime: n,
                            timeFormat: i,
                            defaultCurrentTime: r
                        } = this.props;
                    this.setState({
                        currentTime: ef(n ? t.duration - t.currentTime : t.currentTime, t.duration, i) || r
                    })
                };
                addAudioEventListeners = () => {
                    let {
                        audio: e
                    } = this.props;
                    e && !this.hasAddedAudioEventListener && (this.audio = e, this.hasAddedAudioEventListener = !0, e.addEventListener("timeupdate", this.handleAudioCurrentTimeChange), e.addEventListener("loadedmetadata", this.handleAudioCurrentTimeChange))
                };
                componentDidMount() {
                    this.addAudioEventListeners()
                }
                componentDidUpdate() {
                    this.addAudioEventListeners()
                }
                componentWillUnmount() {
                    this.audio && this.hasAddedAudioEventListener && (this.audio.removeEventListener("timeupdate", this.handleAudioCurrentTimeChange), this.audio.removeEventListener("loadedmetadata", this.handleAudioCurrentTimeChange))
                }
                render() {
                    return this.state.currentTime
                }
            }
            class ew extends o.PureComponent {
                hasAddedAudioEventListener = !1;
                constructor(e) {
                    super(e);
                    let {
                        audio: t,
                        timeFormat: n,
                        defaultDuration: i
                    } = e;
                    this.state = {
                        duration: t ? ef(t.duration, t.duration, n) : i
                    }
                }
                state = {
                    duration: this.props.audio ? ef(this.props.audio.duration, this.props.audio.duration, this.props.timeFormat) : this.props.defaultDuration
                };
                handleAudioDurationChange = e => {
                    let t = e.target,
                        {
                            timeFormat: n,
                            defaultDuration: i
                        } = this.props;
                    this.setState({
                        duration: ef(t.duration, t.duration, n) || i
                    })
                };
                addAudioEventListeners = () => {
                    let {
                        audio: e
                    } = this.props;
                    e && !this.hasAddedAudioEventListener && (this.audio = e, this.hasAddedAudioEventListener = !0, e.addEventListener("durationchange", this.handleAudioDurationChange), e.addEventListener("abort", this.handleAudioDurationChange))
                };
                componentDidMount() {
                    this.addAudioEventListeners()
                }
                componentDidUpdate() {
                    this.addAudioEventListeners()
                }
                componentWillUnmount() {
                    this.audio && this.hasAddedAudioEventListener && (this.audio.removeEventListener("durationchange", this.handleAudioDurationChange), this.audio.removeEventListener("abort", this.handleAudioDurationChange))
                }
                render() {
                    return this.state.duration
                }
            }
            class eE extends o.Component {
                hasAddedAudioEventListener = !1;
                volumeBar = (0, o.createRef)();
                volumeAnimationTimer = 0;
                lastVolume = this.props.volume;
                state = {
                    currentVolumePos: `${(this.lastVolume/1*100||0).toFixed(2)}%`,
                    hasVolumeAnimation: !1,
                    isDraggingVolume: !1
                };
                getCurrentVolume = e => {
                    let t, n;
                    let {
                        audio: i
                    } = this.props;
                    if (!this.volumeBar.current) return {
                        currentVolume: i.volume,
                        currentVolumePos: this.state.currentVolumePos
                    };
                    let r = this.volumeBar.current.getBoundingClientRect(),
                        o = r.width,
                        s = eh(e) - r.left;
                    return s < 0 ? (t = 0, n = "0%") : s > r.width ? (t = 1, n = "100%") : (t = s / o, n = `${s/o*100}%`), {
                        currentVolume: t,
                        currentVolumePos: n
                    }
                };
                handleContextMenu = e => {
                    e.preventDefault()
                };
                handleClickVolumeButton = () => {
                    let {
                        audio: e
                    } = this.props;
                    e.volume > 0 ? (this.lastVolume = e.volume, e.volume = 0) : e.volume = this.lastVolume
                };
                handleVolumnControlMouseOrTouchDown = e => {
                    e.stopPropagation();
                    let {
                        audio: t
                    } = this.props, {
                        currentVolume: n,
                        currentVolumePos: i
                    } = this.getCurrentVolume(e.nativeEvent);
                    t.volume = n, this.setState({
                        isDraggingVolume: !0,
                        currentVolumePos: i
                    }), e.nativeEvent instanceof MouseEvent ? (window.addEventListener("mousemove", this.handleWindowMouseOrTouchMove), window.addEventListener("mouseup", this.handleWindowMouseOrTouchUp)) : (window.addEventListener("touchmove", this.handleWindowMouseOrTouchMove), window.addEventListener("touchend", this.handleWindowMouseOrTouchUp))
                };
                handleWindowMouseOrTouchMove = e => {
                    e instanceof MouseEvent && e.preventDefault(), e.stopPropagation();
                    let {
                        audio: t
                    } = this.props, n = window.getSelection();
                    n && "Range" === n.type && n.empty();
                    let {
                        isDraggingVolume: i
                    } = this.state;
                    if (i) {
                        let {
                            currentVolume: n,
                            currentVolumePos: i
                        } = this.getCurrentVolume(e);
                        t.volume = n, this.setState({
                            currentVolumePos: i
                        })
                    }
                };
                handleWindowMouseOrTouchUp = e => {
                    e.stopPropagation(), this.setState({
                        isDraggingVolume: !1
                    }), e instanceof MouseEvent ? (window.removeEventListener("mousemove", this.handleWindowMouseOrTouchMove), window.removeEventListener("mouseup", this.handleWindowMouseOrTouchUp)) : (window.removeEventListener("touchmove", this.handleWindowMouseOrTouchMove), window.removeEventListener("touchend", this.handleWindowMouseOrTouchUp))
                };
                handleAudioVolumeChange = e => {
                    let {
                        isDraggingVolume: t
                    } = this.state, {
                        volume: n
                    } = e.target;
                    (this.lastVolume > 0 && 0 === n || 0 === this.lastVolume && n > 0) && this.props.onMuteChange(), this.lastVolume = n, t || (this.setState({
                        hasVolumeAnimation: !0,
                        currentVolumePos: `${(n/1*100||0).toFixed(2)}%`
                    }), clearTimeout(this.volumeAnimationTimer), this.volumeAnimationTimer = setTimeout(() => {
                        this.setState({
                            hasVolumeAnimation: !1
                        })
                    }, 100))
                };
                componentDidUpdate() {
                    let {
                        audio: e
                    } = this.props;
                    e && !this.hasAddedAudioEventListener && (this.audio = e, this.hasAddedAudioEventListener = !0, e.addEventListener("volumechange", this.handleAudioVolumeChange))
                }
                componentWillUnmount() {
                    this.audio && this.hasAddedAudioEventListener && this.audio.removeEventListener("volumechange", this.handleAudioVolumeChange), clearTimeout(this.volumeAnimationTimer)
                }
                render() {
                    let {
                        audio: e,
                        showFilledVolume: t,
                        i18nVolumeControl: n
                    } = this.props, {
                        currentVolumePos: i,
                        hasVolumeAnimation: r
                    } = this.state, {
                        volume: s
                    } = e || {};
                    return o.createElement("div", {
                        ref: this.volumeBar,
                        onMouseDown: this.handleVolumnControlMouseOrTouchDown,
                        onTouchStart: this.handleVolumnControlMouseOrTouchDown,
                        onContextMenu: this.handleContextMenu,
                        role: "progressbar",
                        "aria-label": n,
                        "aria-valuemin": 0,
                        "aria-valuemax": 100,
                        "aria-valuenow": Number((100 * s).toFixed(0)),
                        tabIndex: 0,
                        className: "rhap_volume-bar-area"
                    }, o.createElement("div", {
                        className: "rhap_volume-bar"
                    }, o.createElement("div", {
                        className: "rhap_volume-indicator",
                        style: {
                            left: i,
                            transitionDuration: r ? ".1s" : "0s"
                        }
                    }), t && o.createElement("div", {
                        className: "rhap_volume-filled",
                        style: {
                            width: i
                        }
                    })))
                }
            }
            let eb = ((r = {}).CURRENT_TIME = "CURRENT_TIME", r.CURRENT_LEFT_TIME = "CURRENT_LEFT_TIME", r.PROGRESS_BAR = "PROGRESS_BAR", r.DURATION = "DURATION", r.ADDITIONAL_CONTROLS = "ADDITIONAL_CONTROLS", r.MAIN_CONTROLS = "MAIN_CONTROLS", r.VOLUME_CONTROLS = "VOLUME_CONTROLS", r.LOOP = "LOOP", r.VOLUME = "VOLUME", r);
            class eS extends o.Component {
                static defaultI18nAriaLabels = {
                    player: "Audio player",
                    progressControl: "Audio progress control",
                    volumeControl: "Volume control",
                    play: "Play",
                    pause: "Pause",
                    rewind: "Rewind",
                    forward: "Forward",
                    previous: "Previous",
                    next: "Skip",
                    loop: "Disable loop",
                    loopOff: "Enable loop",
                    volume: "Mute",
                    volumeMute: "Unmute"
                };
                static defaultProps = {
                    progressJumpSteps: {
                        backward: 5e3,
                        forward: 5e3
                    },
                    progressJumpStep: 5e3
                };
                audio = (0, o.createRef)();
                progressBar = (0, o.createRef)();
                container = (0, o.createRef)();
                lastVolume = this.props.volume ? ? 1;
                togglePlay = e => {
                    e.stopPropagation();
                    let t = this.audio.current;
                    (t.paused || t.ended) && t.src ? this.playAudioPromise() : t.paused || t.pause()
                };
                playAudioPromise = () => {
                    this.audio.current.error && this.audio.current.load();
                    let e = this.audio.current.play();
                    e ? e.then(null).catch(e => {
                        let {
                            onPlayError: t
                        } = this.props;
                        t && t(Error(e))
                    }) : this.forceUpdate()
                };
                isPlaying = () => {
                    let e = this.audio.current;
                    return !!e && !e.paused && !e.ended
                };
                handlePlay = e => {
                    this.forceUpdate(), this.props.onPlay && this.props.onPlay(e)
                };
                handlePause = e => {
                    this.audio && (this.forceUpdate(), this.props.onPause && this.props.onPause(e))
                };
                handleEnded = e => {
                    this.audio && (this.forceUpdate(), this.props.onEnded && this.props.onEnded(e))
                };
                handleAbort = e => {
                    this.props.onAbort && this.props.onAbort(e)
                };
                handleClickVolumeButton = () => {
                    let e = this.audio.current;
                    e.volume > 0 ? (this.lastVolume = e.volume, e.volume = 0) : e.volume = this.lastVolume
                };
                handleMuteChange = () => {
                    this.forceUpdate()
                };
                handleClickLoopButton = () => {
                    this.audio.current.loop = !this.audio.current.loop, this.forceUpdate()
                };
                handleClickRewind = () => {
                    let {
                        progressJumpSteps: e,
                        progressJumpStep: t
                    } = this.props, n = e.backward || t;
                    this.setJumpTime(-n)
                };
                handleClickForward = () => {
                    let {
                        progressJumpSteps: e,
                        progressJumpStep: t
                    } = this.props, n = e.forward || t;
                    this.setJumpTime(n)
                };
                setJumpTime = e => {
                    let t = this.audio.current,
                        {
                            duration: n,
                            currentTime: i
                        } = t;
                    if (t.readyState === t.HAVE_NOTHING || t.readyState === t.HAVE_METADATA || !isFinite(n) || !isFinite(i)) try {
                        t.load()
                    } catch (e) {
                        return this.props.onChangeCurrentTimeError && this.props.onChangeCurrentTimeError(e)
                    }
                    let r = i + e / 1e3;
                    r < 0 ? (t.currentTime = 0, r = 0) : r > n ? (t.currentTime = n, r = n) : t.currentTime = r
                };
                setJumpVolume = e => {
                    let t = this.audio.current.volume + e;
                    t < 0 ? t = 0 : t > 1 && (t = 1), this.audio.current.volume = t
                };
                handleKeyDown = e => {
                    if (this.props.hasDefaultKeyBindings ? ? !0) switch (e.key) {
                        case " ":
                            (e.target === this.container.current || e.target === this.progressBar.current) && (e.preventDefault(), this.togglePlay(e));
                            break;
                        case "ArrowLeft":
                            this.handleClickRewind();
                            break;
                        case "ArrowRight":
                            this.handleClickForward();
                            break;
                        case "ArrowUp":
                            e.preventDefault(), this.setJumpVolume(this.props.volumeJumpStep);
                            break;
                        case "ArrowDown":
                            e.preventDefault(), this.setJumpVolume(-this.props.volumeJumpStep);
                            break;
                        case "l":
                            this.handleClickLoopButton();
                            break;
                        case "m":
                            this.handleClickVolumeButton()
                    }
                };
                renderUIModules = e => e.map((e, t) => this.renderUIModule(e, t));
                renderUIModule = (e, t) => {
                    let {
                        defaultCurrentTime: n = "--:--",
                        progressUpdateInterval: i = 20,
                        showDownloadProgress: r = !0,
                        showFilledProgress: s = !0,
                        showFilledVolume: a = !1,
                        defaultDuration: l = "--:--",
                        customIcons: u = {},
                        showSkipControls: c = !1,
                        onClickPrevious: d,
                        onClickNext: h,
                        onChangeCurrentTimeError: p,
                        showJumpControls: f = !0,
                        customAdditionalControls: m = [eb.LOOP],
                        customVolumeControls: g = [eb.VOLUME],
                        muted: v = !1,
                        timeFormat: A = "auto",
                        volume: y = 1,
                        loop: w = !1,
                        mse: E,
                        i18nAriaLabels: b = eS.defaultI18nAriaLabels
                    } = this.props;
                    switch (e) {
                        case eb.CURRENT_TIME:
                            return o.createElement("div", {
                                key: t,
                                id: "rhap_current-time",
                                className: "rhap_time rhap_current-time"
                            }, o.createElement(ey, {
                                audio: this.audio.current,
                                isLeftTime: !1,
                                defaultCurrentTime: n,
                                timeFormat: A
                            }));
                        case eb.CURRENT_LEFT_TIME:
                            return o.createElement("div", {
                                key: t,
                                id: "rhap_current-left-time",
                                className: "rhap_time rhap_current-left-time"
                            }, o.createElement(ey, {
                                audio: this.audio.current,
                                isLeftTime: !0,
                                defaultCurrentTime: n,
                                timeFormat: A
                            }));
                        case eb.PROGRESS_BAR:
                            return o.createElement(eA, {
                                key: t,
                                ref: this.progressBar,
                                audio: this.audio.current,
                                progressUpdateInterval: i,
                                showDownloadProgress: r,
                                showFilledProgress: s,
                                onSeek: E && E.onSeek,
                                onChangeCurrentTimeError: p,
                                srcDuration: E && E.srcDuration,
                                i18nProgressBar: b.progressControl
                            });
                        case eb.DURATION:
                            return o.createElement("div", {
                                key: t,
                                className: "rhap_time rhap_total-time"
                            }, E && E.srcDuration ? ef(E.srcDuration, E.srcDuration, this.props.timeFormat) : o.createElement(ew, {
                                audio: this.audio.current,
                                defaultDuration: l,
                                timeFormat: A
                            }));
                        case eb.ADDITIONAL_CONTROLS:
                            return o.createElement("div", {
                                key: t,
                                className: "rhap_additional-controls"
                            }, this.renderUIModules(m));
                        case eb.MAIN_CONTROLS:
                            {
                                let e;
                                let n = this.isPlaying();
                                return e = n ? u.pause ? u.pause : o.createElement(eu, {
                                    icon: "mdi:pause-circle"
                                }) : u.play ? u.play : o.createElement(eu, {
                                    icon: "mdi:play-circle"
                                }),
                                o.createElement("div", {
                                    key: t,
                                    className: "rhap_main-controls"
                                }, c && o.createElement("button", {
                                    "aria-label": b.previous,
                                    className: "rhap_button-clear rhap_main-controls-button rhap_skip-button",
                                    type: "button",
                                    onClick: d
                                }, u.previous ? u.previous : o.createElement(eu, {
                                    icon: "mdi:skip-previous"
                                })), f && o.createElement("button", {
                                    "aria-label": b.rewind,
                                    className: "rhap_button-clear rhap_main-controls-button rhap_rewind-button",
                                    type: "button",
                                    onClick: this.handleClickRewind
                                }, u.rewind ? u.rewind : o.createElement(eu, {
                                    icon: "mdi:rewind"
                                })), o.createElement("button", {
                                    "aria-label": n ? b.pause : b.play,
                                    className: "rhap_button-clear rhap_main-controls-button rhap_play-pause-button",
                                    type: "button",
                                    onClick: this.togglePlay
                                }, e), f && o.createElement("button", {
                                    "aria-label": b.forward,
                                    className: "rhap_button-clear rhap_main-controls-button rhap_forward-button",
                                    type: "button",
                                    onClick: this.handleClickForward
                                }, u.forward ? u.forward : o.createElement(eu, {
                                    icon: "mdi:fast-forward"
                                })), c && o.createElement("button", {
                                    "aria-label": b.next,
                                    className: "rhap_button-clear rhap_main-controls-button rhap_skip-button",
                                    type: "button",
                                    onClick: h
                                }, u.next ? u.next : o.createElement(eu, {
                                    icon: "mdi:skip-next"
                                })))
                            }
                        case eb.VOLUME_CONTROLS:
                            return o.createElement("div", {
                                key: t,
                                className: "rhap_volume-controls"
                            }, this.renderUIModules(g));
                        case eb.LOOP:
                            {
                                let e;
                                let n = this.audio.current ? this.audio.current.loop : w;
                                return e = n ? u.loop ? u.loop : o.createElement(eu, {
                                    icon: "mdi:repeat"
                                }) : u.loopOff ? u.loopOff : o.createElement(eu, {
                                    icon: "mdi:repeat-off"
                                }),
                                o.createElement("button", {
                                    key: t,
                                    "aria-label": n ? b.loop : b.loopOff,
                                    className: "rhap_button-clear rhap_repeat-button",
                                    type: "button",
                                    onClick: this.handleClickLoopButton
                                }, e)
                            }
                        case eb.VOLUME:
                            {
                                let e;
                                let {
                                    volume: n = v ? 0 : y
                                } = this.audio.current || {};
                                return e = n ? u.volume ? u.volume : o.createElement(eu, {
                                    icon: "mdi:volume-high"
                                }) : u.volume ? u.volumeMute : o.createElement(eu, {
                                    icon: "mdi:volume-mute"
                                }),
                                o.createElement("div", {
                                    key: t,
                                    className: "rhap_volume-container"
                                }, o.createElement("button", {
                                    "aria-label": n ? b.volume : b.volumeMute,
                                    onClick: this.handleClickVolumeButton,
                                    type: "button",
                                    className: "rhap_button-clear rhap_volume-button"
                                }, e), o.createElement(eE, {
                                    audio: this.audio.current,
                                    volume: n,
                                    onMuteChange: this.handleMuteChange,
                                    showFilledVolume: a,
                                    i18nVolumeControl: b.volumeControl
                                }))
                            }
                        default:
                            if (!(0, o.isValidElement)(e)) return null;
                            return e.key ? e : (0, o.cloneElement)(e, {
                                key: t
                            })
                    }
                };
                componentDidMount() {
                    this.forceUpdate();
                    let e = this.audio.current;
                    this.props.muted ? e.volume = 0 : e.volume = this.lastVolume, e.addEventListener("error", e => {
                        let t = e.target;
                        if (t.error && t.currentTime === t.duration) return this.props.onEnded && this.props.onEnded(e);
                        this.props.onError && this.props.onError(e)
                    }), e.addEventListener("canplay", e => {
                        this.props.onCanPlay && this.props.onCanPlay(e)
                    }), e.addEventListener("canplaythrough", e => {
                        this.props.onCanPlayThrough && this.props.onCanPlayThrough(e)
                    }), e.addEventListener("play", this.handlePlay), e.addEventListener("abort", this.handleAbort), e.addEventListener("ended", this.handleEnded), e.addEventListener("playing", e => {
                        this.props.onPlaying && this.props.onPlaying(e)
                    }), e.addEventListener("seeking", e => {
                        this.props.onSeeking && this.props.onSeeking(e)
                    }), e.addEventListener("seeked", e => {
                        this.props.onSeeked && this.props.onSeeked(e)
                    }), e.addEventListener("waiting", e => {
                        this.props.onWaiting && this.props.onWaiting(e)
                    }), e.addEventListener("emptied", e => {
                        this.props.onEmptied && this.props.onEmptied(e)
                    }), e.addEventListener("stalled", e => {
                        this.props.onStalled && this.props.onStalled(e)
                    }), e.addEventListener("suspend", e => {
                        this.props.onSuspend && this.props.onSuspend(e)
                    }), e.addEventListener("loadstart", e => {
                        this.props.onLoadStart && this.props.onLoadStart(e)
                    }), e.addEventListener("loadedmetadata", e => {
                        this.props.onLoadedMetaData && this.props.onLoadedMetaData(e)
                    }), e.addEventListener("loadeddata", e => {
                        this.props.onLoadedData && this.props.onLoadedData(e)
                    }), e.addEventListener("pause", this.handlePause), e.addEventListener("timeupdate", em(e => {
                        this.props.onListen && this.props.onListen(e)
                    }, this.props.listenInterval)), e.addEventListener("volumechange", e => {
                        this.props.onVolumeChange && this.props.onVolumeChange(e)
                    }), e.addEventListener("encrypted", e => {
                        let {
                            mse: t
                        } = this.props;
                        t && t.onEcrypted && t.onEcrypted(e)
                    })
                }
                componentDidUpdate(e) {
                    let {
                        src: t,
                        autoPlayAfterSrcChange: n
                    } = this.props;
                    e.src !== t && (n ? this.playAudioPromise() : this.forceUpdate())
                }
                render() {
                    let {
                        className: e = "",
                        src: t,
                        loop: n = !1,
                        preload: i = "auto",
                        autoPlay: r = !1,
                        crossOrigin: s,
                        mediaGroup: a,
                        header: l,
                        footer: u,
                        layout: c = "stacked",
                        customProgressBarSection: d = [eb.CURRENT_TIME, eb.PROGRESS_BAR, eb.DURATION],
                        customControlsSection: h = [eb.ADDITIONAL_CONTROLS, eb.MAIN_CONTROLS, eb.VOLUME_CONTROLS],
                        children: p,
                        style: f,
                        i18nAriaLabels: m = eS.defaultI18nAriaLabels
                    } = this.props, g = this.audio.current ? this.audio.current.loop : n, v = this.isPlaying() ? "rhap_play-status--playing" : "rhap_play-status--paused";
                    return o.createElement("div", {
                        role: "group",
                        tabIndex: 0,
                        "aria-label": m.player,
                        className: `rhap_container ${g?"rhap_loop--on":"rhap_loop--off"} ${v} ${e}`,
                        onKeyDown: this.handleKeyDown,
                        ref: this.container,
                        style: f
                    }, o.createElement("audio", {
                        src: t,
                        controls: !1,
                        loop: g,
                        autoPlay: r,
                        preload: i,
                        crossOrigin: s,
                        mediaGroup: a,
                        ref: this.audio
                    }, p), l && o.createElement("div", {
                        className: "rhap_header"
                    }, l), o.createElement("div", {
                        className: `rhap_main ${ed(c)}`
                    }, o.createElement("div", {
                        className: "rhap_progress-section"
                    }, this.renderUIModules(d)), o.createElement("div", {
                        className: "rhap_controls-section"
                    }, this.renderUIModules(h))), u && o.createElement("div", {
                        className: "rhap_footer"
                    }, u))
                }
            }
            var ex = eS
        },
        9844: function(e, t, n) {
            "use strict";
            n.d(t, {
                e: function() {
                    return d
                }
            });
            var i = n(7294);

            function r(e, t, n, i) {
                return new(n || (n = Promise))(function(r, o) {
                    function s(e) {
                        try {
                            l(i.next(e))
                        } catch (e) {
                            o(e)
                        }
                    }

                    function a(e) {
                        try {
                            l(i.throw(e))
                        } catch (e) {
                            o(e)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? r(e.value) : ((t = e.value) instanceof n ? t : new n(function(e) {
                            e(t)
                        })).then(s, a)
                    }
                    l((i = i.apply(e, t || [])).next())
                })
            }

            function o(e, t) {
                var n, i, r, o, s = {
                    label: 0,
                    sent: function() {
                        if (1 & r[0]) throw r[1];
                        return r[1]
                    },
                    trys: [],
                    ops: []
                };
                return o = {
                    next: a(0),
                    throw: a(1),
                    return: a(2)
                }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                    return this
                }), o;

                function a(o) {
                    return function(a) {
                        return function(o) {
                            if (n) throw TypeError("Generator is already executing.");
                            for (; s;) try {
                                if (n = 1, i && (r = 2 & o[0] ? i.return : o[0] ? i.throw || ((r = i.return) && r.call(i), 0) : i.next) && !(r = r.call(i, o[1])).done) return r;
                                switch (i = 0, r && (o = [2 & o[0], r.value]), o[0]) {
                                    case 0:
                                    case 1:
                                        r = o;
                                        break;
                                    case 4:
                                        return s.label++, {
                                            value: o[1],
                                            done: !1
                                        };
                                    case 5:
                                        s.label++, i = o[1], o = [0];
                                        continue;
                                    case 7:
                                        o = s.ops.pop(), s.trys.pop();
                                        continue;
                                    default:
                                        if (!(r = (r = s.trys).length > 0 && r[r.length - 1]) && (6 === o[0] || 2 === o[0])) {
                                            s = 0;
                                            continue
                                        }
                                        if (3 === o[0] && (!r || o[1] > r[0] && o[1] < r[3])) {
                                            s.label = o[1];
                                            break
                                        }
                                        if (6 === o[0] && s.label < r[1]) {
                                            s.label = r[1], r = o;
                                            break
                                        }
                                        if (r && s.label < r[2]) {
                                            s.label = r[2], s.ops.push(o);
                                            break
                                        }
                                        r[2] && s.ops.pop(), s.trys.pop();
                                        continue
                                }
                                o = t.call(e, s)
                            } catch (e) {
                                o = [6, e], i = 0
                            } finally {
                                n = r = 0
                            }
                            if (5 & o[0]) throw o[1];
                            return {
                                value: o[0] ? o[1] : void 0,
                                done: !0
                            }
                        }([o, a])
                    }
                }
            }

            function s(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    n = t && e[t],
                    i = 0;
                if (n) return n.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && i >= e.length && (e = void 0), {
                            value: e && e[i++],
                            done: !e
                        }
                    }
                };
                throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function a(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var i, r, o = n.call(e),
                    s = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(i = o.next()).done;) s.push(i.value)
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        i && !i.done && (n = o.return) && n.call(o)
                    } finally {
                        if (r) throw r.error
                    }
                }
                return s
            }

            function l(e, t, n) {
                if (n || 2 == arguments.length)
                    for (var i, r = 0, o = t.length; r < o; r++) !i && r in t || (i || (i = Array.prototype.slice.call(t, 0, r)), i[r] = t[r]);
                return e.concat(i || Array.prototype.slice.call(t))
            }

            function u(e, t, n, i, u) {
                for (var d = [], h = 5; h < arguments.length; h++) d[h - 5] = arguments[h];
                return r(this, void 0, void 0, function() {
                    var h, p, f, m, g;
                    return o(this, function(v) {
                        switch (v.label) {
                            case 0:
                                v.trys.push([0, 12, 13, 14]), p = (h = s(d)).next(), v.label = 1;
                            case 1:
                                if (p.done) return [3, 11];
                                switch (typeof(f = p.value)) {
                                    case "string":
                                        return [3, 2];
                                    case "number":
                                        return [3, 4];
                                    case "function":
                                        return [3, 6]
                                }
                                return [3, 8];
                            case 2:
                                return [4, function(e, t, n, i, u, d) {
                                    return r(this, void 0, void 0, function() {
                                        var h, p;
                                        return o(this, function(f) {
                                            switch (f.label) {
                                                case 0:
                                                    var m, g;
                                                    return m = h = e.textContent || "", g = a(n).slice(0), p = l(l([], a(m), !1), [NaN], !1).findIndex(function(e, t) {
                                                        return g[t] !== e
                                                    }), [4, function(e, t, n, i, l) {
                                                        return r(this, void 0, void 0, function() {
                                                            var r, u, d, h, p, f, m, g, v, A, y, w;
                                                            return o(this, function(E) {
                                                                switch (E.label) {
                                                                    case 0:
                                                                        if (r = t, l) {
                                                                            for (u = 0, d = 1; d < t.length; d++)
                                                                                if (p = (h = a([t[d - 1], t[d]], 2))[0], (f = h[1]).length > p.length || "" === f) {
                                                                                    u = d;
                                                                                    break
                                                                                }
                                                                            r = t.slice(u, t.length)
                                                                        }
                                                                        E.label = 1;
                                                                    case 1:
                                                                        E.trys.push([1, 6, 7, 8]), g = (m = s(function(e) {
                                                                            var t, n, i, r, a;
                                                                            return o(this, function(l) {
                                                                                switch (l.label) {
                                                                                    case 0:
                                                                                        t = function(e) {
                                                                                            return o(this, function(t) {
                                                                                                switch (t.label) {
                                                                                                    case 0:
                                                                                                        return [4, {
                                                                                                            op: function(t) {
                                                                                                                return requestAnimationFrame(function() {
                                                                                                                    return t.textContent = e
                                                                                                                })
                                                                                                            },
                                                                                                            opCode: function(t) {
                                                                                                                var n = t.textContent || "";
                                                                                                                return "" === e || n.length > e.length ? "DELETE" : "WRITING"
                                                                                                            }
                                                                                                        }];
                                                                                                    case 1:
                                                                                                        return t.sent(), [2]
                                                                                                }
                                                                                            })
                                                                                        }, l.label = 1;
                                                                                    case 1:
                                                                                        l.trys.push([1, 6, 7, 8]), i = (n = s(e)).next(), l.label = 2;
                                                                                    case 2:
                                                                                        return i.done ? [3, 5] : [5, t(i.value)];
                                                                                    case 3:
                                                                                        l.sent(), l.label = 4;
                                                                                    case 4:
                                                                                        return i = n.next(), [3, 2];
                                                                                    case 5:
                                                                                        return [3, 8];
                                                                                    case 6:
                                                                                        return r = {
                                                                                            error: l.sent()
                                                                                        }, [3, 8];
                                                                                    case 7:
                                                                                        try {
                                                                                            i && !i.done && (a = n.return) && a.call(n)
                                                                                        } finally {
                                                                                            if (r) throw r.error
                                                                                        }
                                                                                        return [7];
                                                                                    case 8:
                                                                                        return [2]
                                                                                }
                                                                            })
                                                                        }(r))).next(), E.label = 2;
                                                                    case 2:
                                                                        return g.done ? [3, 5] : (A = "WRITING" === (v = g.value).opCode(e) ? n + n * (Math.random() - .5) : i + i * (Math.random() - .5), v.op(e), [4, c(A)]);
                                                                    case 3:
                                                                        E.sent(), E.label = 4;
                                                                    case 4:
                                                                        return g = m.next(), [3, 2];
                                                                    case 5:
                                                                        return [3, 8];
                                                                    case 6:
                                                                        return y = {
                                                                            error: E.sent()
                                                                        }, [3, 8];
                                                                    case 7:
                                                                        try {
                                                                            g && !g.done && (w = m.return) && w.call(m)
                                                                        } finally {
                                                                            if (y) throw y.error
                                                                        }
                                                                        return [7];
                                                                    case 8:
                                                                        return [2]
                                                                }
                                                            })
                                                        })
                                                    }(e, l(l([], a(function(e, t, n) {
                                                        var i, r;
                                                        return void 0 === n && (n = 0), o(this, function(o) {
                                                            switch (o.label) {
                                                                case 0:
                                                                    r = (i = t(e)).length, o.label = 1;
                                                                case 1:
                                                                    return r > n ? [4, i.slice(0, --r).join("")] : [3, 3];
                                                                case 2:
                                                                    return o.sent(), [3, 1];
                                                                case 3:
                                                                    return [2]
                                                            }
                                                        })
                                                    }(h, t, p)), !1), a(function(e, t, n) {
                                                        var i, r;
                                                        return void 0 === n && (n = 0), o(this, function(o) {
                                                            switch (o.label) {
                                                                case 0:
                                                                    r = (i = t(e)).length, o.label = 1;
                                                                case 1:
                                                                    return n < r ? [4, i.slice(0, ++n).join("")] : [3, 3];
                                                                case 2:
                                                                    return o.sent(), [3, 1];
                                                                case 3:
                                                                    return [2]
                                                            }
                                                        })
                                                    }(n, t, p)), !1), i, u, d)];
                                                case 1:
                                                    return f.sent(), [2]
                                            }
                                        })
                                    })
                                }(e, t, f, n, i, u)];
                            case 3:
                            case 5:
                            case 7:
                                return v.sent(), [3, 10];
                            case 4:
                                return [4, c(f)];
                            case 6:
                                return [4, f.apply(void 0, l([e, t, n, i, u], a(d), !1))];
                            case 8:
                                return [4, f];
                            case 9:
                                v.sent(), v.label = 10;
                            case 10:
                                return p = h.next(), [3, 1];
                            case 11:
                                return [3, 14];
                            case 12:
                                return m = {
                                    error: v.sent()
                                }, [3, 14];
                            case 13:
                                try {
                                    p && !p.done && (g = h.return) && g.call(h)
                                } finally {
                                    if (m) throw m.error
                                }
                                return [7];
                            case 14:
                                return [2]
                        }
                    })
                })
            }

            function c(e) {
                return r(this, void 0, void 0, function() {
                    return o(this, function(t) {
                        switch (t.label) {
                            case 0:
                                return [4, new Promise(function(t) {
                                    return setTimeout(t, e)
                                })];
                            case 1:
                                return t.sent(), [2]
                        }
                    })
                })
            }! function(e, t) {
                void 0 === t && (t = {});
                var n = t.insertAt;
                if (e && "undefined" != typeof document) {
                    var i = document.head || document.getElementsByTagName("head")[0],
                        r = document.createElement("style");
                    r.type = "text/css", "top" === n && i.firstChild ? i.insertBefore(r, i.firstChild) : i.appendChild(r), r.styleSheet ? r.styleSheet.cssText = e : r.appendChild(document.createTextNode(e))
                }
            }(".index-module_type__E-SaG::after {\n  content: '|';\n  animation: index-module_cursor__PQg0P 1.1s infinite step-start;\n}\n\n@keyframes index-module_cursor__PQg0P {\n  50% {\n    opacity: 0;\n  }\n}\n");
            var d = (0, i.memo)((0, i.forwardRef)(function(e, t) {
                var n = e.sequence,
                    r = e.repeat,
                    o = e.className,
                    s = e.speed,
                    c = void 0 === s ? 40 : s,
                    d = e.deletionSpeed,
                    h = e.omitDeletionAnimation,
                    p = void 0 !== h && h,
                    f = e.preRenderFirstString,
                    m = e.wrapper,
                    g = e.splitter,
                    v = void 0 === g ? function(e) {
                        return l([], a(e), !1)
                    } : g,
                    A = e.cursor,
                    y = void 0 === A || A,
                    w = e.style,
                    E = function(e, t) {
                        var n = {};
                        for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && 0 > t.indexOf(i) && (n[i] = e[i]);
                        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                            var r = 0;
                            for (i = Object.getOwnPropertySymbols(e); r < i.length; r++) 0 > t.indexOf(i[r]) && Object.prototype.propertyIsEnumerable.call(e, i[r]) && (n[i[r]] = e[i[r]])
                        }
                        return n
                    }(e, ["sequence", "repeat", "className", "speed", "deletionSpeed", "omitDeletionAnimation", "preRenderFirstString", "wrapper", "splitter", "cursor", "style"]),
                    b = E["aria-label"],
                    S = E["aria-hidden"],
                    x = E.role;
                d || (d = c);
                var C = [, , ].fill(40);
                [c, d].forEach(function(e, t) {
                    switch (typeof e) {
                        case "number":
                            C[t] = Math.abs(e - 100);
                            break;
                        case "object":
                            var n = e.type,
                                i = e.value;
                            if ("number" != typeof i) break;
                            "keyStrokeDelayInMs" === n && (C[t] = i)
                    }
                });
                var T, L, _, M, P, O, k, R, I, D = C[0],
                    N = C[1],
                    F = (T = t, void 0 === L && (L = null), _ = (0, i.useRef)(L), (0, i.useEffect)(function() {
                        T && ("function" == typeof T ? T(_.current) : T.current = _.current)
                    }, [T]), _),
                    j = "index-module_type__E-SaG";
                M = o ? "".concat(y ? j + " " : "").concat(o) : y ? j : "", P = (0, i.useRef)(function() {
                    var e, t = n;
                    r === 1 / 0 ? e = u : "number" == typeof r && (t = Array(1 + r).fill(n).flat());
                    var i = e ? l(l([], a(t), !1), [e], !1) : l([], a(t), !1);
                    return u.apply(void 0, l([F.current, v, D, N, p], a(i), !1)),
                        function() {
                            F.current
                        }
                }), O = (0, i.useRef)(), k = (0, i.useRef)(!1), R = (0, i.useRef)(!1), I = a((0, i.useState)(0), 2)[1], k.current && (R.current = !0), (0, i.useEffect)(function() {
                    return k.current || (O.current = P.current(), k.current = !0), I(function(e) {
                            return e + 1
                        }),
                        function() {
                            R.current && O.current && O.current()
                        }
                }, []);
                var B = void 0 !== f && f ? n.find(function(e) {
                    return "string" == typeof e
                }) || "" : null;
                return i.createElement(void 0 === m ? "span" : m, {
                    "aria-hidden": S,
                    "aria-label": b,
                    role: x,
                    style: w,
                    className: M,
                    children: b ? i.createElement("span", {
                        "aria-hidden": "true",
                        ref: F,
                        children: B
                    }) : B,
                    ref: b ? void 0 : F
                })
            }), function(e, t) {
                return !0
            })
        },
        689: function(e, t, n) {
            "use strict";
            n.d(t, {
                p: function() {
                    return G
                }
            });
            var i, r, o, s, a, l, u, c, d = n(7294),
                h = n.t(d, 2),
                p = Object.defineProperty,
                f = (e, t, n) => t in e ? p(e, t, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: n
                }) : e[t] = n,
                m = (e, t, n) => (f(e, "symbol" != typeof t ? t + "" : t, n), n);
            let g = new class {
                    constructor() {
                        m(this, "current", this.detect()), m(this, "handoffState", "pending"), m(this, "currentId", 0)
                    }
                    set(e) {
                        this.current !== e && (this.handoffState = "pending", this.currentId = 0, this.current = e)
                    }
                    reset() {
                        this.set(this.detect())
                    }
                    nextId() {
                        return ++this.currentId
                    }
                    get isServer() {
                        return "server" === this.current
                    }
                    get isClient() {
                        return "client" === this.current
                    }
                    detect() {
                        return "undefined" == typeof window || "undefined" == typeof document ? "server" : "client"
                    }
                    handoff() {
                        "pending" === this.handoffState && (this.handoffState = "complete")
                    }
                    get isHandoffComplete() {
                        return "complete" === this.handoffState
                    }
                },
                v = (e, t) => {
                    g.isServer ? (0, d.useEffect)(e, t) : (0, d.useLayoutEffect)(e, t)
                },
                A = function(e) {
                    let t;
                    let n = (t = (0, d.useRef)(e), v(() => {
                        t.current = e
                    }, [e]), t);
                    return d.useCallback((...e) => n.current(...e), [n])
                },
                y = null != (u = d.useId) ? u : function() {
                    let e = function() {
                            let e;
                            let t = (e = "undefined" == typeof document, (0, h.useSyncExternalStore)(() => () => {}, () => !1, () => !e)),
                                [n, i] = d.useState(g.isHandoffComplete);
                            return n && !1 === g.isHandoffComplete && i(!1), d.useEffect(() => {
                                !0 !== n && i(!0)
                            }, [n]), d.useEffect(() => g.handoff(), []), !t && n
                        }(),
                        [t, n] = d.useState(e ? () => g.nextId() : null);
                    return v(() => {
                        null === t && n(g.nextId())
                    }, [t]), null != t ? "" + t : void 0
                };

            function w(e) {
                var t;
                if (e.type) return e.type;
                let n = null != (t = e.as) ? t : "button";
                if ("string" == typeof n && "button" === n.toLowerCase()) return "button"
            }
            let E = Symbol();

            function b(...e) {
                let t = (0, d.useRef)(e);
                (0, d.useEffect)(() => {
                    t.current = e
                }, [e]);
                let n = A(e => {
                    for (let n of t.current) null != n && ("function" == typeof n ? n(e) : n.current = e)
                });
                return e.every(e => null == e || (null == e ? void 0 : e[E])) ? void 0 : n
            }
            let S = (0, d.createContext)(null);
            S.displayName = "OpenClosedContext";
            var x = ((i = x || {})[i.Open = 1] = "Open", i[i.Closed = 2] = "Closed", i[i.Closing = 4] = "Closing", i[i.Opening = 8] = "Opening", i);

            function C({
                value: e,
                children: t
            }) {
                return d.createElement(S.Provider, {
                    value: e
                }, t)
            }

            function T(e, t, ...n) {
                if (e in t) {
                    let i = t[e];
                    return "function" == typeof i ? i(...n) : i
                }
                let i = Error(`Tried to handle "${e}" but there is no handler defined. Only defined handlers are: ${Object.keys(t).map(e=>`"${e}"`).join(", ")}.`);
                throw Error.captureStackTrace && Error.captureStackTrace(i, T), i
            }

            function L(...e) {
                return Array.from(new Set(e.flatMap(e => "string" == typeof e ? e.split(" ") : []))).filter(Boolean).join(" ")
            }
            var _ = ((r = _ || {})[r.None = 0] = "None", r[r.RenderStrategy = 1] = "RenderStrategy", r[r.Static = 2] = "Static", r),
                M = ((o = M || {})[o.Unmount = 0] = "Unmount", o[o.Hidden = 1] = "Hidden", o);

            function P({
                ourProps: e,
                theirProps: t,
                slot: n,
                defaultTag: i,
                features: r,
                visible: o = !0,
                name: s,
                mergeRefs: a
            }) {
                a = null != a ? a : R;
                let l = I(t, e);
                if (o) return O(l, n, i, s, a);
                let u = null != r ? r : 0;
                if (2 & u) {
                    let {
                        static: e = !1,
                        ...t
                    } = l;
                    if (e) return O(t, n, i, s, a)
                }
                if (1 & u) {
                    let {
                        unmount: e = !0,
                        ...t
                    } = l;
                    return T(e ? 0 : 1, {
                        0: () => null,
                        1: () => O({ ...t,
                            hidden: !0,
                            style: {
                                display: "none"
                            }
                        }, n, i, s, a)
                    })
                }
                return O(l, n, i, s, a)
            }

            function O(e, t = {}, n, i, r) {
                let {
                    as: o = n,
                    children: s,
                    refName: a = "ref",
                    ...l
                } = F(e, ["unmount", "static"]), u = void 0 !== e.ref ? {
                    [a]: e.ref
                } : {}, c = "function" == typeof s ? s(t) : s;
                "className" in l && l.className && "function" == typeof l.className && (l.className = l.className(t));
                let h = {};
                if (t) {
                    let e = !1,
                        n = [];
                    for (let [i, r] of Object.entries(t)) "boolean" == typeof r && (e = !0), !0 === r && n.push(i);
                    e && (h["data-headlessui-state"] = n.join(" "))
                }
                if (o === d.Fragment && Object.keys(N(l)).length > 0) {
                    if (!(0, d.isValidElement)(c) || Array.isArray(c) && c.length > 1) throw Error(['Passing props on "Fragment"!', "", `The current component <${i} /> is rendering a "Fragment".`, "However we need to passthrough the following props:", Object.keys(l).map(e => `  - ${e}`).join(`
`), "", "You can apply a few solutions:", ['Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".', "Render a single element as the child so that we can forward the props onto that element."].map(e => `  - ${e}`).join(`
`)].join(`
`));
                    let e = c.props,
                        t = "function" == typeof(null == e ? void 0 : e.className) ? (...t) => L(null == e ? void 0 : e.className(...t), l.className) : L(null == e ? void 0 : e.className, l.className);
                    return (0, d.cloneElement)(c, Object.assign({}, I(c.props, N(F(l, ["ref"]))), h, u, {
                        ref: r(c.ref, u.ref)
                    }, t ? {
                        className: t
                    } : {}))
                }
                return (0, d.createElement)(o, Object.assign({}, F(l, ["ref"]), o !== d.Fragment && u, o !== d.Fragment && h), c)
            }

            function k() {
                let e = (0, d.useRef)([]),
                    t = (0, d.useCallback)(t => {
                        for (let n of e.current) null != n && ("function" == typeof n ? n(t) : n.current = t)
                    }, []);
                return (...n) => {
                    if (!n.every(e => null == e)) return e.current = n, t
                }
            }

            function R(...e) {
                return e.every(e => null == e) ? void 0 : t => {
                    for (let n of e) null != n && ("function" == typeof n ? n(t) : n.current = t)
                }
            }

            function I(...e) {
                if (0 === e.length) return {};
                if (1 === e.length) return e[0];
                let t = {},
                    n = {};
                for (let i of e)
                    for (let e in i) e.startsWith("on") && "function" == typeof i[e] ? (null != n[e] || (n[e] = []), n[e].push(i[e])) : t[e] = i[e];
                if (t.disabled || t["aria-disabled"]) return Object.assign(t, Object.fromEntries(Object.keys(n).map(e => [e, void 0])));
                for (let e in n) Object.assign(t, {
                    [e](t, ...i) {
                        for (let r of n[e]) {
                            if ((t instanceof Event || (null == t ? void 0 : t.nativeEvent) instanceof Event) && t.defaultPrevented) return;
                            r(t, ...i)
                        }
                    }
                });
                return t
            }

            function D(e) {
                var t;
                return Object.assign((0, d.forwardRef)(e), {
                    displayName: null != (t = e.displayName) ? t : e.name
                })
            }

            function N(e) {
                let t = Object.assign({}, e);
                for (let e in t) void 0 === t[e] && delete t[e];
                return t
            }

            function F(e, t = []) {
                let n = Object.assign({}, e);
                for (let e of t) e in n && delete n[e];
                return n
            }
            let j = null != (c = d.startTransition) ? c : function(e) {
                e()
            };
            var B = ((s = B || {}).Space = " ", s.Enter = "Enter", s.Escape = "Escape", s.Backspace = "Backspace", s.Delete = "Delete", s.ArrowLeft = "ArrowLeft", s.ArrowUp = "ArrowUp", s.ArrowRight = "ArrowRight", s.ArrowDown = "ArrowDown", s.Home = "Home", s.End = "End", s.PageUp = "PageUp", s.PageDown = "PageDown", s.Tab = "Tab", s),
                U = ((a = U || {})[a.Open = 0] = "Open", a[a.Closed = 1] = "Closed", a),
                z = ((l = z || {})[l.ToggleDisclosure = 0] = "ToggleDisclosure", l[l.CloseDisclosure = 1] = "CloseDisclosure", l[l.SetButtonId = 2] = "SetButtonId", l[l.SetPanelId = 3] = "SetPanelId", l[l.LinkPanel = 4] = "LinkPanel", l[l.UnlinkPanel = 5] = "UnlinkPanel", l);
            let W = {
                    0: e => ({ ...e,
                        disclosureState: T(e.disclosureState, {
                            0: 1,
                            1: 0
                        })
                    }),
                    1: e => 1 === e.disclosureState ? e : { ...e,
                        disclosureState: 1
                    },
                    4: e => !0 === e.linkedPanel ? e : { ...e,
                        linkedPanel: !0
                    },
                    5: e => !1 === e.linkedPanel ? e : { ...e,
                        linkedPanel: !1
                    },
                    2: (e, t) => e.buttonId === t.buttonId ? e : { ...e,
                        buttonId: t.buttonId
                    },
                    3: (e, t) => e.panelId === t.panelId ? e : { ...e,
                        panelId: t.panelId
                    }
                },
                Y = (0, d.createContext)(null);

            function V(e) {
                let t = (0, d.useContext)(Y);
                if (null === t) {
                    let t = Error(`<${e} /> is missing a parent <Disclosure /> component.`);
                    throw Error.captureStackTrace && Error.captureStackTrace(t, V), t
                }
                return t
            }
            Y.displayName = "DisclosureContext";
            let H = (0, d.createContext)(null);
            H.displayName = "DisclosureAPIContext";
            let X = (0, d.createContext)(null);

            function J(e, t) {
                return T(t.type, W, e, t)
            }
            X.displayName = "DisclosurePanelContext";
            let $ = d.Fragment,
                Q = _.RenderStrategy | _.Static,
                G = Object.assign(D(function(e, t) {
                    let {
                        defaultOpen: n = !1,
                        ...i
                    } = e, r = (0, d.useRef)(null), o = b(t, function(e, t = !0) {
                        return Object.assign(e, {
                            [E]: t
                        })
                    }(e => {
                        r.current = e
                    }, void 0 === e.as || e.as === d.Fragment)), s = (0, d.useRef)(null), a = (0, d.useRef)(null), l = (0, d.useReducer)(J, {
                        disclosureState: n ? 0 : 1,
                        linkedPanel: !1,
                        buttonRef: a,
                        panelRef: s,
                        buttonId: null,
                        panelId: null
                    }), [{
                        disclosureState: u,
                        buttonId: c
                    }, h] = l, p = A(e => {
                        h({
                            type: 1
                        });
                        let t = g.isServer ? null : r instanceof Node ? r.ownerDocument : null != r && r.hasOwnProperty("current") && r.current instanceof Node ? r.current.ownerDocument : document;
                        if (!t || !c) return;
                        let n = e ? e instanceof HTMLElement ? e : e.current instanceof HTMLElement ? e.current : t.getElementById(c) : t.getElementById(c);
                        null == n || n.focus()
                    }), f = (0, d.useMemo)(() => ({
                        close: p
                    }), [p]), m = (0, d.useMemo)(() => ({
                        open: 0 === u,
                        close: p
                    }), [u, p]);
                    return d.createElement(Y.Provider, {
                        value: l
                    }, d.createElement(H.Provider, {
                        value: f
                    }, d.createElement(C, {
                        value: T(u, {
                            0: x.Open,
                            1: x.Closed
                        })
                    }, P({
                        ourProps: {
                            ref: o
                        },
                        theirProps: i,
                        slot: m,
                        defaultTag: $,
                        name: "Disclosure"
                    }))))
                }), {
                    Button: D(function(e, t) {
                        let n = y(),
                            {
                                id: i = `headlessui-disclosure-button-${n}`,
                                ...r
                            } = e,
                            [o, s] = V("Disclosure.Button"),
                            a = (0, d.useContext)(X),
                            l = null !== a && a === o.panelId,
                            u = (0, d.useRef)(null),
                            c = b(u, t, l ? null : o.buttonRef),
                            h = k();
                        (0, d.useEffect)(() => {
                            if (!l) return s({
                                type: 2,
                                buttonId: i
                            }), () => {
                                s({
                                    type: 2,
                                    buttonId: null
                                })
                            }
                        }, [i, s, l]);
                        let p = A(e => {
                                var t;
                                if (l) {
                                    if (1 === o.disclosureState) return;
                                    switch (e.key) {
                                        case B.Space:
                                        case B.Enter:
                                            e.preventDefault(), e.stopPropagation(), s({
                                                type: 0
                                            }), null == (t = o.buttonRef.current) || t.focus()
                                    }
                                } else switch (e.key) {
                                    case B.Space:
                                    case B.Enter:
                                        e.preventDefault(), e.stopPropagation(), s({
                                            type: 0
                                        })
                                }
                            }),
                            f = A(e => {
                                e.key === B.Space && e.preventDefault()
                            }),
                            m = A(t => {
                                var n;
                                (function(e) {
                                    let t = e.parentElement,
                                        n = null;
                                    for (; t && !(t instanceof HTMLFieldSetElement);) t instanceof HTMLLegendElement && (n = t), t = t.parentElement;
                                    let i = (null == t ? void 0 : t.getAttribute("disabled")) === "";
                                    return !(i && function(e) {
                                        if (!e) return !1;
                                        let t = e.previousElementSibling;
                                        for (; null !== t;) {
                                            if (t instanceof HTMLLegendElement) return !1;
                                            t = t.previousElementSibling
                                        }
                                        return !0
                                    }(n)) && i
                                })(t.currentTarget) || e.disabled || (l ? (s({
                                    type: 0
                                }), null == (n = o.buttonRef.current) || n.focus()) : s({
                                    type: 0
                                }))
                            }),
                            g = (0, d.useMemo)(() => ({
                                open: 0 === o.disclosureState
                            }), [o]),
                            E = function(e, t) {
                                let [n, i] = (0, d.useState)(() => w(e));
                                return v(() => {
                                    i(w(e))
                                }, [e.type, e.as]), v(() => {
                                    n || t.current && t.current instanceof HTMLButtonElement && !t.current.hasAttribute("type") && i("button")
                                }, [n, t]), n
                            }(e, u);
                        return P({
                            mergeRefs: h,
                            ourProps: l ? {
                                ref: c,
                                type: E,
                                onKeyDown: p,
                                onClick: m
                            } : {
                                ref: c,
                                id: i,
                                type: E,
                                "aria-expanded": 0 === o.disclosureState,
                                "aria-controls": o.linkedPanel ? o.panelId : void 0,
                                onKeyDown: p,
                                onKeyUp: f,
                                onClick: m
                            },
                            theirProps: r,
                            slot: g,
                            defaultTag: "button",
                            name: "Disclosure.Button"
                        })
                    }),
                    Panel: D(function(e, t) {
                        let n = y(),
                            {
                                id: i = `headlessui-disclosure-panel-${n}`,
                                ...r
                            } = e,
                            [o, s] = V("Disclosure.Panel"),
                            {
                                close: a
                            } = function e(t) {
                                let n = (0, d.useContext)(H);
                                if (null === n) {
                                    let n = Error(`<${t} /> is missing a parent <Disclosure /> component.`);
                                    throw Error.captureStackTrace && Error.captureStackTrace(n, e), n
                                }
                                return n
                            }("Disclosure.Panel"),
                            l = k(),
                            u = b(t, o.panelRef, e => {
                                j(() => s({
                                    type: e ? 4 : 5
                                }))
                            });
                        (0, d.useEffect)(() => (s({
                            type: 3,
                            panelId: i
                        }), () => {
                            s({
                                type: 3,
                                panelId: null
                            })
                        }), [i, s]);
                        let c = (0, d.useContext)(S),
                            h = null !== c ? (c & x.Open) === x.Open : 0 === o.disclosureState,
                            p = (0, d.useMemo)(() => ({
                                open: 0 === o.disclosureState,
                                close: a
                            }), [o, a]);
                        return d.createElement(X.Provider, {
                            value: o.panelId
                        }, P({
                            mergeRefs: l,
                            ourProps: {
                                ref: u,
                                id: i
                            },
                            theirProps: r,
                            slot: p,
                            defaultTag: "div",
                            features: Q,
                            visible: h,
                            name: "Disclosure.Panel"
                        }))
                    })
                })
        },
        1562: function(e, t, n) {
            "use strict";

            function i(e) {
                let t, n, i, r = e && e.colors || ["#D61C59", "#E7D84B", "#1B8798"],
                    o = e && e.element,
                    s = o || document.body,
                    a = window.innerWidth,
                    l = window.innerHeight,
                    u = {
                        x: a / 2,
                        y: a / 2
                    },
                    c = {
                        x: a / 2,
                        y: a / 2
                    },
                    d = [],
                    h = [],
                    p = window.matchMedia("(prefers-reduced-motion: reduce)");

                function f() {
                    if (p.matches) return console.log("This browser has prefers reduced motion turned on, so the cursor did not init"), !1;
                    n = (t = document.createElement("canvas")).getContext("2d"), t.style.top = "0px", t.style.left = "0px", t.style.pointerEvents = "none", o ? (t.style.position = "absolute", s.appendChild(t), t.width = s.clientWidth, t.height = s.clientHeight) : (t.style.position = "fixed", s.appendChild(t), t.width = a, t.height = l), n.font = "21px serif", n.textBaseline = "middle", n.textAlign = "center", r.forEach(e => {
                            let t = n.measureText("*"),
                                i = document.createElement("canvas"),
                                r = i.getContext("2d");
                            i.width = t.width, i.height = t.actualBoundingBoxAscent + t.actualBoundingBoxDescent, r.fillStyle = e, r.textAlign = "center", r.font = "21px serif", r.textBaseline = "middle", r.fillText("*", i.width / 2, t.actualBoundingBoxAscent), h.push(i)
                        }), s.addEventListener("mousemove", v), s.addEventListener("touchmove", g, {
                            passive: !0
                        }), s.addEventListener("touchstart", g, {
                            passive: !0
                        }), window.addEventListener("resize", m),
                        function e() {
                            (function() {
                                if (0 != d.length) {
                                    n.clearRect(0, 0, a, l);
                                    for (let e = 0; e < d.length; e++) d[e].update(n);
                                    for (let e = d.length - 1; e >= 0; e--) d[e].lifeSpan < 0 && d.splice(e, 1);
                                    0 == d.length && n.clearRect(0, 0, a, l)
                                }
                            })(), i = requestAnimationFrame(e)
                        }()
                }

                function m(e) {
                    a = window.innerWidth, l = window.innerHeight, o ? (t.width = s.clientWidth, t.height = s.clientHeight) : (t.width = a, t.height = l)
                }

                function g(e) {
                    if (e.touches.length > 0)
                        for (let t = 0; t < e.touches.length; t++) A(e.touches[t].clientX, e.touches[t].clientY, h[Math.floor(Math.random() * h.length)])
                }

                function v(e) {
                    window.requestAnimationFrame(() => {
                        if (o) {
                            let t = s.getBoundingClientRect();
                            u.x = e.clientX - t.left, u.y = e.clientY - t.top
                        } else u.x = e.clientX, u.y = e.clientY;
                        Math.hypot(u.x - c.x, u.y - c.y) > 1.5 && (A(u.x, u.y, h[Math.floor(Math.random() * r.length)]), c.x = u.x, c.y = u.y)
                    })
                }

                function A(e, t, n) {
                    d.push(new w(e, t, n))
                }

                function y() {
                    t.remove(), cancelAnimationFrame(i), s.removeEventListener("mousemove", v), s.removeEventListener("touchmove", g), s.removeEventListener("touchstart", g), window.addEventListener("resize", m)
                }

                function w(e, t, n) {
                    let i = Math.floor(30 * Math.random() + 60);
                    this.initialLifeSpan = i, this.lifeSpan = i, this.velocity = {
                        x: (.5 > Math.random() ? -1 : 1) * (Math.random() / 2),
                        y: .7 * Math.random() + .9
                    }, this.position = {
                        x: e,
                        y: t
                    }, this.canv = n, this.update = function(e) {
                        this.position.x += this.velocity.x, this.position.y += this.velocity.y, this.lifeSpan--, this.velocity.y += .02;
                        let t = Math.max(this.lifeSpan / this.initialLifeSpan, 0);
                        e.drawImage(this.canv, this.position.x - this.canv.width / 2 * t, this.position.y - this.canv.height / 2, this.canv.width * t, this.canv.height * t)
                    }
                }
                return p.onchange = () => {
                    p.matches ? y() : f()
                }, f(), {
                    destroy: y
                }
            }

            function r(e) {
                let t, n, i, r = e && e.element,
                    o = r || document.body,
                    s = window.innerWidth,
                    a = window.innerHeight,
                    l = {
                        x: s / 2,
                        y: s / 2
                    },
                    u = [],
                    c = e ? .particles || 15,
                    d = e ? .rate || .4,
                    h = e ? .baseImageSrc || "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAATCAYAAACk9eypAAAAAXNSR0IArs4c6QAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAhGVYSWZNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAEgAAAABAAAASAAAAAEAA6ABAAMAAAABAAEAAKACAAQAAAABAAAADKADAAQAAAABAAAAEwAAAAAChpcNAAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAABqElEQVQoFY3SPUvDQBgH8BREpRHExYiDgmLFl6WC+AYmWeyLg4i7buJX8DMpOujgyxGvUYeCgzhUQUSKKLUS0+ZyptXh8Z5Ti621ekPyJHl+uftfomhaf9Ei5JyxXKfynyEA6EYcLHpwyflT958GAQ7DTABNHd8EbtDbEH2BD5QEQmi2mM8P/Iq+A0SzszEg+3sPjDnDdVEtQKQbMUidHD3xVzf6A9UDEmEm+8h9KTqTVUjT+vB53aHrCbAPiceYq1dQI1Aqv4EhMll0jzv+Y0yiRgCnLRSYyDQHVoqUXe4uKL9l+L7GXC4vkMhE6eW/AOJs9k583ORDUyXMZ8F5SVHVVnllmPNKSFagAJ5DofaqGXw/gHBYg51dIldkmknY3tguv3jOtHR4+MqAzaraJXbEhqHhcQlwGSOi5pytVQHZLN5s0WNe8HPrLYlFsO20RPHkImxsbmHdLJFI76th7Z4SeuF53hTeFLvhRCJRCTKZKxgdnRDbW+iozFJbBMw14/ElwGYc0egMBMFzT21f5Rog33Z7dX02GBm7WV5ZfT5Nn5bE3zuCDe9UxdTpNvK+5AAAAABJRU5ErkJggg==",
                    p = !1,
                    f = new Image;
                f.src = h;
                let m = window.matchMedia("(prefers-reduced-motion: reduce)");

                function g() {
                    if (m.matches) return console.log("This browser has prefers reduced motion turned on, so the cursor did not init"), !1;
                    n = (t = document.createElement("canvas")).getContext("2d"), t.style.top = "0px", t.style.left = "0px", t.style.pointerEvents = "none", r ? (t.style.position = "absolute", o.appendChild(t), t.width = o.clientWidth, t.height = o.clientHeight) : (t.style.position = "fixed", document.body.appendChild(t), t.width = s, t.height = a), o.addEventListener("mousemove", A), window.addEventListener("resize", v),
                        function e() {
                            let t, r;
                            n.clearRect(0, 0, s, a), t = l.x, r = l.y, u.forEach(function(e, i, o) {
                                let s = o[i + 1] || o[0];
                                e.position.x = t, e.position.y = r, e.move(n), t += (s.position.x - e.position.x) * d, r += (s.position.y - e.position.y) * d
                            }), i = requestAnimationFrame(e)
                        }()
                }

                function v(e) {
                    s = window.innerWidth, a = window.innerHeight, r ? (t.width = o.clientWidth, t.height = o.clientHeight) : (t.width = s, t.height = a)
                }

                function A(e) {
                    var t, n;
                    if (r) {
                        let t = o.getBoundingClientRect();
                        l.x = e.clientX - t.left, l.y = e.clientY - t.top
                    } else l.x = e.clientX, l.y = e.clientY;
                    if (!1 === p) {
                        p = !0;
                        for (let e = 0; e < c; e++) t = l.x, n = l.y, u.push(new w(t, n, f))
                    }
                }

                function y() {
                    t.remove(), cancelAnimationFrame(i), o.removeEventListener("mousemove", A), window.addEventListener("resize", v)
                }

                function w(e, t, n) {
                    this.position = {
                        x: e,
                        y: t
                    }, this.image = n, this.move = function(e) {
                        e.drawImage(this.image, this.position.x, this.position.y)
                    }
                }
                return m.onchange = () => {
                    m.matches ? y() : g()
                }, g(), {
                    destroy: y
                }
            }

            function o(e) {
                let t, n, i = e && e.element,
                    r = i || document.body,
                    o = window.innerWidth,
                    s = window.innerHeight,
                    a = {
                        x: o / 2,
                        y: o / 2
                    },
                    l = new function(e, t, n, i) {
                        this.position = {
                            x: e,
                            y: t
                        }, this.width = n, this.lag = i, this.moveTowards = function(e, t, n) {
                            this.position.x += (e - this.position.x) / this.lag, this.position.y += (t - this.position.y) / this.lag, n.fillStyle = u, n.beginPath(), n.arc(this.position.x, this.position.y, this.width, 0, 2 * Math.PI), n.fill(), n.closePath()
                        }
                    }(o / 2, s / 2, 10, 10),
                    u = e ? .color || "#323232a6",
                    c = window.matchMedia("(prefers-reduced-motion: reduce)");

                function d() {
                    if (c.matches) return console.log("This browser has prefers reduced motion turned on, so the cursor did not init"), !1;
                    n = (t = document.createElement("canvas")).getContext("2d"), t.style.top = "0px", t.style.left = "0px", t.style.pointerEvents = "none", i ? (t.style.position = "absolute", r.appendChild(t), t.width = r.clientWidth, t.height = r.clientHeight) : (t.style.position = "fixed", document.body.appendChild(t), t.width = o, t.height = s), r.addEventListener("mousemove", p), window.addEventListener("resize", h), f()
                }

                function h(e) {
                    o = window.innerWidth, s = window.innerHeight, i ? (t.width = r.clientWidth, t.height = r.clientHeight) : (t.width = o, t.height = s)
                }

                function p(e) {
                    if (i) {
                        let t = r.getBoundingClientRect();
                        a.x = e.clientX - t.left, a.y = e.clientY - t.top
                    } else a.x = e.clientX, a.y = e.clientY
                }

                function f() {
                    n.clearRect(0, 0, o, s), l.moveTowards(a.x, a.y, n), requestAnimationFrame(f)
                }

                function m() {
                    t.remove(), cancelAnimationFrame(f), r.removeEventListener("mousemove", p), window.addEventListener("resize", h)
                }
                return c.onchange = () => {
                    c.matches ? m() : d()
                }, d(), {
                    destroy: m
                }
            }

            function s(e) {
                let t = e && e.element,
                    n = t || document.body,
                    i = e && e.randomDelay,
                    r = e && e.minDelay || 5,
                    o = e && e.maxDelay || 50,
                    s = e && e.lifeSpan || 40,
                    a, l, u, c = window.innerWidth,
                    d = window.innerHeight,
                    h = {
                        x: c / 2,
                        y: c / 2
                    },
                    p = [],
                    f = new Image;
                e && e.image ? f.src = e.image : f.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAATCAYAAACk9eypAAAAAXNSR0IArs4c6QAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAhGVYSWZNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAEgAAAABAAAASAAAAAEAA6ABAAMAAAABAAEAAKACAAQAAAABAAAADKADAAQAAAABAAAAEwAAAAAChpcNAAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAABqElEQVQoFY3SPUvDQBgH8BREpRHExYiDgmLFl6WC+AYmWeyLg4i7buJX8DMpOujgyxGvUYeCgzhUQUSKKLUS0+ZyptXh8Z5Ti621ekPyJHl+uftfomhaf9Ei5JyxXKfynyEA6EYcLHpwyflT958GAQ7DTABNHd8EbtDbEH2BD5QEQmi2mM8P/Iq+A0SzszEg+3sPjDnDdVEtQKQbMUidHD3xVzf6A9UDEmEm+8h9KTqTVUjT+vB53aHrCbAPiceYq1dQI1Aqv4EhMll0jzv+Y0yiRgCnLRSYyDQHVoqUXe4uKL9l+L7GXC4vkMhE6eW/AOJs9k583ORDUyXMZ8F5SVHVVnllmPNKSFagAJ5DofaqGXw/gHBYg51dIldkmknY3tguv3jOtHR4+MqAzaraJXbEhqHhcQlwGSOi5pytVQHZLN5s0WNe8HPrLYlFsO20RPHkImxsbmHdLJFI76th7Z4SeuF53hTeFLvhRCJRCTKZKxgdnRDbW+iozFJbBMw14/ElwGYc0egMBMFzT21f5Rog33Z7dX02GBm7WV5ZfT5Nn5bE3zuCDe9UxdTpNvK+5AAAAABJRU5ErkJggg==";
                let m = window.matchMedia("(prefers-reduced-motion: reduce)");

                function g() {
                    if (m.matches) return console.log("This browser has prefers reduced motion turned on, so the cursor did not init"), !1;
                    l = (a = document.createElement("canvas")).getContext("2d"), a.style.top = "0px", a.style.left = "0px", a.style.pointerEvents = "none", t ? (a.style.position = "absolute", n.appendChild(a), a.width = n.clientWidth, a.height = n.clientHeight) : (a.style.position = "fixed", document.body.appendChild(a), a.width = c, a.height = d), n.addEventListener("mousemove", b), n.addEventListener("touchmove", A, {
                            passive: !0
                        }), n.addEventListener("touchstart", A, {
                            passive: !0
                        }), window.addEventListener("resize", v),
                        function e() {
                            (function() {
                                if (0 != p.length) {
                                    l.clearRect(0, 0, c, d);
                                    for (let e = 0; e < p.length; e++) p[e].update(l);
                                    for (let e = p.length - 1; e >= 0; e--) p[e].lifeSpan < 0 && p.splice(e, 1);
                                    0 == p.length && l.clearRect(0, 0, c, d)
                                }
                            })(), u = requestAnimationFrame(e)
                        }()
                }

                function v(e) {
                    c = window.innerWidth, d = window.innerHeight, t ? (a.width = n.clientWidth, a.height = n.clientHeight) : (a.width = c, a.height = d)
                }

                function A(e) {
                    if (e.touches.length > 0)
                        for (let t = 0; t < e.touches.length; t++) S(e.touches[t].clientX, e.touches[t].clientY, f)
                }
                m.onchange = () => {
                    m.matches ? x() : g()
                };
                let y = () => Math.floor(Math.random() * (o - r + 1)) + r,
                    w = Date.now(),
                    E = y();

                function b(e) {
                    if (i) {
                        if (w + E > Date.now()) return;
                        w = Date.now(), E = y()
                    }
                    if (t) {
                        let t = n.getBoundingClientRect();
                        h.x = e.clientX - t.left, h.y = e.clientY - t.top
                    } else h.x = e.clientX, h.y = e.clientY;
                    S(h.x, h.y, f)
                }

                function S(e, t, n) {
                    p.push(new C(e, t, n))
                }

                function x() {
                    a.remove(), cancelAnimationFrame(u), n.removeEventListener("mousemove", b), n.removeEventListener("touchmove", A), n.removeEventListener("touchstart", A), window.addEventListener("resize", v)
                }

                function C(e, t, n) {
                    this.initialLifeSpan = s, this.lifeSpan = s, this.position = {
                        x: e,
                        y: t
                    }, this.image = n, this.update = function(e) {
                        this.lifeSpan--;
                        let t = Math.max(this.lifeSpan / this.initialLifeSpan, 0);
                        e.globalAlpha = t, e.drawImage(this.image, this.position.x, this.position.y)
                    }
                }
                return g(), {
                    destroy: x
                }
            }
            n.d(t, {
                $N: function() {
                    return s
                },
                Y2: function() {
                    return o
                },
                f4: function() {
                    return i
                },
                n8: function() {
                    return r
                }
            })
        },
        6825: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return u
                }
            });
            var i = n(5893),
                r = n(7294);
            let o = (e, t, n, i) => {
                    e.style.transition = `${t} ${n}ms ${i}`
                },
                s = (e, t, n) => Math.min(Math.max(e, t), n);
            class a {
                constructor(e, t) {
                    this.glareAngle = 0, this.glareOpacity = 0, this.calculateGlareSize = e => {
                        let {
                            width: t,
                            height: n
                        } = e, i = Math.sqrt(t ** 2 + n ** 2);
                        return {
                            width: i,
                            height: i
                        }
                    }, this.setSize = e => {
                        let t = this.calculateGlareSize(e);
                        this.glareEl.style.width = `${t.width}px`, this.glareEl.style.height = `${t.height}px`
                    }, this.update = (e, t, n, i) => {
                        this.updateAngle(e, t.glareReverse), this.updateOpacity(e, t, n, i)
                    }, this.updateAngle = (e, t) => {
                        let {
                            xPercentage: n,
                            yPercentage: i
                        } = e;
                        this.glareAngle = (n ? Math.atan2(i, -n) * (180 / Math.PI) : 0) - (t ? 180 : 0)
                    }, this.updateOpacity = (e, t, n, i) => {
                        let {
                            xPercentage: r,
                            yPercentage: o
                        } = e, {
                            glarePosition: a,
                            glareReverse: l,
                            glareMaxOpacity: u
                        } = t, c = n ? -1 : 1, d = i ? -1 : 1, h = l ? -1 : 1, p = 0;
                        switch (a) {
                            case "top":
                                p = -r * c * h;
                                break;
                            case "right":
                                p = o * d * h;
                                break;
                            case "bottom":
                            case void 0:
                                p = r * c * h;
                                break;
                            case "left":
                                p = -o * d * h;
                                break;
                            case "all":
                                p = Math.hypot(r, o)
                        }
                        let f = s(p, 0, 100);
                        this.glareOpacity = f * u / 100
                    }, this.render = e => {
                        let {
                            glareColor: t
                        } = e;
                        this.glareEl.style.transform = `rotate(${this.glareAngle}deg) translate(-50%, -50%)`, this.glareEl.style.opacity = this.glareOpacity.toString(), this.glareEl.style.background = `linear-gradient(0deg, rgba(255,255,255,0) 0%, ${t} 100%)`
                    }, this.glareWrapperEl = document.createElement("div"), this.glareEl = document.createElement("div"), this.glareWrapperEl.appendChild(this.glareEl), this.glareWrapperEl.className = "glare-wrapper", this.glareEl.className = "glare";
                    let n = this.calculateGlareSize(e),
                        i = {
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transformOrigin: "0% 0%",
                            pointerEvents: "none",
                            width: `${n.width}px`,
                            height: `${n.height}px`
                        };
                    Object.assign(this.glareWrapperEl.style, {
                        position: "absolute",
                        top: "0",
                        left: "0",
                        width: "100%",
                        height: "100%",
                        overflow: "hidden",
                        borderRadius: t,
                        WebkitMaskImage: "-webkit-radial-gradient(white, black)",
                        pointerEvents: "none"
                    }), Object.assign(this.glareEl.style, i)
                }
            }
            class l {
                constructor() {
                    this.tiltAngleX = 0, this.tiltAngleY = 0, this.tiltAngleXPercentage = 0, this.tiltAngleYPercentage = 0, this.update = (e, t) => {
                        this.updateTilt(e, t), this.updateTiltManualInput(e, t), this.updateTiltReverse(t), this.updateTiltLimits(t)
                    }, this.updateTilt = (e, t) => {
                        let {
                            xPercentage: n,
                            yPercentage: i
                        } = e, {
                            tiltMaxAngleX: r,
                            tiltMaxAngleY: o
                        } = t;
                        this.tiltAngleX = n * r / 100, this.tiltAngleY = -(i * o / 100 * 1)
                    }, this.updateTiltManualInput = (e, t) => {
                        let {
                            tiltAngleXManual: n,
                            tiltAngleYManual: i,
                            tiltMaxAngleX: r,
                            tiltMaxAngleY: o
                        } = t;
                        (null !== n || null !== i) && (this.tiltAngleX = null !== n ? n : 0, this.tiltAngleY = null !== i ? i : 0, e.xPercentage = 100 * this.tiltAngleX / r, e.yPercentage = 100 * this.tiltAngleY / o)
                    }, this.updateTiltReverse = e => {
                        let t = e.tiltReverse ? -1 : 1;
                        this.tiltAngleX = t * this.tiltAngleX, this.tiltAngleY = t * this.tiltAngleY
                    }, this.updateTiltLimits = e => {
                        let {
                            tiltAxis: t
                        } = e;
                        this.tiltAngleX = s(this.tiltAngleX, -90, 90), this.tiltAngleY = s(this.tiltAngleY, -90, 90), t && (this.tiltAngleX = "x" === t ? this.tiltAngleX : 0, this.tiltAngleY = "y" === t ? this.tiltAngleY : 0)
                    }, this.updateTiltAnglesPercentage = e => {
                        let {
                            tiltMaxAngleX: t,
                            tiltMaxAngleY: n
                        } = e;
                        this.tiltAngleXPercentage = this.tiltAngleX / t * 100, this.tiltAngleYPercentage = this.tiltAngleY / n * 100
                    }, this.render = e => {
                        e.style.transform += `rotateX(${this.tiltAngleX}deg) rotateY(${this.tiltAngleY}deg) `
                    }
                }
            }
            class u extends r.PureComponent {
                constructor() {
                    super(...arguments), this.wrapperEl = {
                        node: null,
                        size: {
                            width: 0,
                            height: 0,
                            left: 0,
                            top: 0
                        },
                        clientPosition: {
                            x: null,
                            y: null,
                            xPercentage: 0,
                            yPercentage: 0
                        },
                        updateAnimationId: null,
                        scale: 1
                    }, this.tilt = null, this.glare = null, this.addDeviceOrientationEventListener = async () => {
                        if (!window.DeviceOrientationEvent) return;
                        let e = DeviceOrientationEvent.requestPermission;
                        "function" == typeof e ? "granted" === await e() && window.addEventListener("deviceorientation", this.onMove) : window.addEventListener("deviceorientation", this.onMove)
                    }, this.setSize = () => {
                        this.setWrapperElSize(), this.glare && this.glare.setSize(this.wrapperEl.size)
                    }, this.mainLoop = e => {
                        null !== this.wrapperEl.updateAnimationId && cancelAnimationFrame(this.wrapperEl.updateAnimationId), this.processInput(e), this.update(e.type), this.wrapperEl.updateAnimationId = requestAnimationFrame(this.renderFrame)
                    }, this.onEnter = e => {
                        let {
                            onEnter: t
                        } = this.props;
                        this.setSize(), this.wrapperEl.node.style.willChange = "transform", this.setTransitions(), t && t({
                            event: e
                        })
                    }, this.onMove = e => {
                        this.mainLoop(e), this.emitOnMove(e)
                    }, this.onLeave = e => {
                        let {
                            onLeave: t
                        } = this.props;
                        if (this.setTransitions(), t && t({
                                event: e
                            }), this.props.reset) {
                            let e = new CustomEvent("autoreset");
                            this.onMove(e)
                        }
                    }, this.processInput = e => {
                        let {
                            scale: t
                        } = this.props;
                        switch (e.type) {
                            case "mousemove":
                                this.wrapperEl.clientPosition.x = e.pageX, this.wrapperEl.clientPosition.y = e.pageY, this.wrapperEl.scale = t;
                                break;
                            case "touchmove":
                                this.wrapperEl.clientPosition.x = e.touches[0].pageX, this.wrapperEl.clientPosition.y = e.touches[0].pageY, this.wrapperEl.scale = t;
                                break;
                            case "deviceorientation":
                                this.processInputDeviceOrientation(e), this.wrapperEl.scale = t;
                                break;
                            case "autoreset":
                                {
                                    let {
                                        tiltAngleXInitial: e,
                                        tiltAngleYInitial: t,
                                        tiltMaxAngleX: n,
                                        tiltMaxAngleY: i
                                    } = this.props;this.wrapperEl.clientPosition.xPercentage = s(e / n * 100, -100, 100),
                                    this.wrapperEl.clientPosition.yPercentage = s(t / i * 100, -100, 100),
                                    this.wrapperEl.scale = 1
                                }
                        }
                    }, this.processInputDeviceOrientation = e => {
                        if (!e.gamma || !e.beta || !this.props.gyroscope) return;
                        let {
                            tiltMaxAngleX: t,
                            tiltMaxAngleY: n
                        } = this.props, i = e.gamma;
                        this.wrapperEl.clientPosition.xPercentage = e.beta / t * 100, this.wrapperEl.clientPosition.yPercentage = i / n * 100, this.wrapperEl.clientPosition.xPercentage = s(this.wrapperEl.clientPosition.xPercentage, -100, 100), this.wrapperEl.clientPosition.yPercentage = s(this.wrapperEl.clientPosition.yPercentage, -100, 100)
                    }, this.update = e => {
                        let {
                            tiltEnable: t,
                            flipVertically: n,
                            flipHorizontally: i
                        } = this.props;
                        "autoreset" !== e && "deviceorientation" !== e && "propChange" !== e && this.updateClientInput(), t && this.tilt.update(this.wrapperEl.clientPosition, this.props), this.updateFlip(), this.tilt.updateTiltAnglesPercentage(this.props), this.glare && this.glare.update(this.wrapperEl.clientPosition, this.props, n, i)
                    }, this.updateClientInput = () => {
                        let e, t;
                        let {
                            trackOnWindow: n
                        } = this.props;
                        if (n) {
                            let {
                                x: n,
                                y: i
                            } = this.wrapperEl.clientPosition;
                            e = i / window.innerHeight * 200 - 100, t = n / window.innerWidth * 200 - 100
                        } else {
                            let {
                                size: {
                                    width: n,
                                    height: i,
                                    left: r,
                                    top: o
                                },
                                clientPosition: {
                                    x: s,
                                    y: a
                                }
                            } = this.wrapperEl;
                            e = (a - o) / i * 200 - 100, t = (s - r) / n * 200 - 100
                        }
                        this.wrapperEl.clientPosition.xPercentage = s(e, -100, 100), this.wrapperEl.clientPosition.yPercentage = s(t, -100, 100)
                    }, this.updateFlip = () => {
                        let {
                            flipVertically: e,
                            flipHorizontally: t
                        } = this.props;
                        e && (this.tilt.tiltAngleX += 180, this.tilt.tiltAngleY *= -1), t && (this.tilt.tiltAngleY += 180)
                    }, this.renderFrame = () => {
                        this.resetWrapperElTransform(), this.renderPerspective(), this.tilt.render(this.wrapperEl.node), this.renderScale(), this.glare && this.glare.render(this.props)
                    }
                }
                componentDidMount() {
                    if (this.tilt = new l, this.initGlare(), this.setSize(), this.addEventListeners(), "undefined" == typeof CustomEvent) return;
                    let e = new CustomEvent("autoreset");
                    this.mainLoop(e);
                    let t = new CustomEvent("initial");
                    this.emitOnMove(t)
                }
                componentWillUnmount() {
                    null !== this.wrapperEl.updateAnimationId && cancelAnimationFrame(this.wrapperEl.updateAnimationId), this.removeEventListeners()
                }
                componentDidUpdate() {
                    let e = new CustomEvent("propChange");
                    this.mainLoop(e), this.emitOnMove(e)
                }
                addEventListeners() {
                    let {
                        trackOnWindow: e,
                        gyroscope: t
                    } = this.props;
                    window.addEventListener("resize", this.setSize), e && (window.addEventListener("mouseenter", this.onEnter), window.addEventListener("mousemove", this.onMove), window.addEventListener("mouseout", this.onLeave), window.addEventListener("touchstart", this.onEnter), window.addEventListener("touchmove", this.onMove), window.addEventListener("touchend", this.onLeave)), t && this.addDeviceOrientationEventListener()
                }
                removeEventListeners() {
                    let {
                        trackOnWindow: e,
                        gyroscope: t
                    } = this.props;
                    window.removeEventListener("resize", this.setSize), e && (window.removeEventListener("mouseenter", this.onEnter), window.removeEventListener("mousemove", this.onMove), window.removeEventListener("mouseout", this.onLeave), window.removeEventListener("touchstart", this.onEnter), window.removeEventListener("touchmove", this.onMove), window.removeEventListener("touchend", this.onLeave)), t && window.DeviceOrientationEvent && window.removeEventListener("deviceorientation", this.onMove)
                }
                setWrapperElSize() {
                    let e = this.wrapperEl.node.getBoundingClientRect();
                    this.wrapperEl.size.width = this.wrapperEl.node.offsetWidth, this.wrapperEl.size.height = this.wrapperEl.node.offsetHeight, this.wrapperEl.size.left = e.left + window.scrollX, this.wrapperEl.size.top = e.top + window.scrollY
                }
                initGlare() {
                    let {
                        glareEnable: e,
                        glareBorderRadius: t
                    } = this.props;
                    e && (this.glare = new a(this.wrapperEl.size, t), this.wrapperEl.node.appendChild(this.glare.glareWrapperEl))
                }
                emitOnMove(e) {
                    let {
                        onMove: t
                    } = this.props;
                    if (!t) return;
                    let n = 0,
                        i = 0;
                    this.glare && (n = this.glare.glareAngle, i = this.glare.glareOpacity), t({
                        tiltAngleX: this.tilt.tiltAngleX,
                        tiltAngleY: this.tilt.tiltAngleY,
                        tiltAngleXPercentage: this.tilt.tiltAngleXPercentage,
                        tiltAngleYPercentage: this.tilt.tiltAngleYPercentage,
                        glareAngle: n,
                        glareOpacity: i,
                        event: e
                    })
                }
                resetWrapperElTransform() {
                    this.wrapperEl.node.style.transform = ""
                }
                renderPerspective() {
                    let {
                        perspective: e
                    } = this.props;
                    this.wrapperEl.node.style.transform += `perspective(${e}px) `
                }
                renderScale() {
                    let {
                        scale: e
                    } = this.wrapperEl;
                    this.wrapperEl.node.style.transform += `scale3d(${e},${e},${e})`
                }
                setTransitions() {
                    let {
                        transitionSpeed: e,
                        transitionEasing: t
                    } = this.props;
                    o(this.wrapperEl.node, "all", e, t), this.glare && o(this.glare.glareEl, "opacity", e, t)
                }
                render() {
                    let {
                        children: e,
                        className: t,
                        style: n
                    } = this.props;
                    return (0, i.jsx)("div", {
                        ref: e => {
                            this.wrapperEl.node = e
                        },
                        onMouseEnter: this.onEnter,
                        onMouseMove: this.onMove,
                        onMouseLeave: this.onLeave,
                        onTouchStart: this.onEnter,
                        onTouchMove: this.onMove,
                        onTouchEnd: this.onLeave,
                        className: t,
                        style: n,
                        children: e
                    })
                }
            }
            u.defaultProps = {
                scale: 1,
                perspective: 1e3,
                flipVertically: !1,
                flipHorizontally: !1,
                reset: !0,
                transitionEasing: "cubic-bezier(.03,.98,.52,.99)",
                transitionSpeed: 400,
                trackOnWindow: !1,
                gyroscope: !1,
                tiltEnable: !0,
                tiltReverse: !1,
                tiltAngleXInitial: 0,
                tiltAngleYInitial: 0,
                tiltMaxAngleX: 20,
                tiltMaxAngleY: 20,
                tiltAxis: void 0,
                tiltAngleXManual: null,
                tiltAngleYManual: null,
                glareEnable: !1,
                glareMaxOpacity: .7,
                glareColor: "#ffffff",
                glarePosition: "bottom",
                glareReverse: !1,
                glareBorderRadius: "0"
            }
        }
    }
]);