self.__BUILD_MANIFEST = function(e) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [e, "static/chunks/pages/index-e499313dda3b0d7c.js"],
        "/404": ["static/chunks/pages/404-82a098c793a3f6e3.js"],
        "/500": ["static/chunks/pages/500-9e8a48f67e2e82ad.js"],
        "/_error": ["static/chunks/pages/_error-54de1933a164a1ff.js"],
        "/[username]": [e, "static/chunks/749-aaf4a2532e8ec30c.js", "static/chunks/pages/[username]-31adcea0b627f346.js"],
        sortedPages: ["/", "/404", "/500", "/_app", "/_error", "/[username]"]
    }
}("static/chunks/891-68e9bf39a5ef3569.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();